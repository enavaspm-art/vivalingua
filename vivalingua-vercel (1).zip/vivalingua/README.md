# VivaLingua

English/Spanish language school site with La Plaza, the AI conversation practice.
Built to run on **Vercel**: static pages plus three small server functions in `api/`.

| File | What it does |
|---|---|
| `api/plaza.js` | La Plaza conversations. Calls Claude with your API key, which never reaches the browser. |
| `api/login.js` | Checks student, teacher and admin passwords on the server. |
| `api/data.js` | Saves students, missions, progress and certificates. Each person only sees what they're allowed to see. |
| `assets/js/vercel-bridge.js` | Connects the pages to those functions. |

## One-time setup in Vercel

1. **Import the repo:** at vercel.com, choose **Add New → Project**, pick the `vivalingua` repository and click **Deploy**. No build settings are needed.
2. **Add the database:** in the project, open **Storage → Create / Connect → Upstash for Redis** and choose the free plan. Connect it to the project. This adds `KV_REST_API_URL` and `KV_REST_API_TOKEN` automatically.
3. **Add environment variables:** open **Settings → Environment Variables** and add:

| Name | Value |
|---|---|
| `ANTHROPIC_API_KEY` | Your key from console.anthropic.com. Set a monthly spending limit there too. |
| `SESSION_SECRET` | Any long random text, at least 32 characters. |
| `ADMIN_PASSWORD` | Your admin password. Admin email defaults to enavaspm@gmail.com; change it with `ADMIN_EMAIL`. |
| `TEACHER_ACCOUNTS` | Optional: `email:password:Name`, comma-separated for several teachers. |
| `ANTHROPIC_MODEL` | Optional. Defaults to `claude-sonnet-5-5`. |
| `PLAZA_LIMIT_VISITOR` / `PLAZA_LIMIT_STUDENT` | Optional. Messages per hour, 30 and 200 by default. |

4. **Redeploy:** open **Deployments → ⋯ → Redeploy** so the new settings take effect.

## How accounts work

- **Students** get a personal password when they finish the placement test, or when the admin adds them. It's shown only once, so they should write it down.
- **Admin and teachers** sign in with the passwords stored in Vercel.
- **La Plaza progress** is saved in each student's browser.
