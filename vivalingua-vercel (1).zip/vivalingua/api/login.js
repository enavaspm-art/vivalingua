// POST /api/login  { email, password } → { token, role, name, email }
'use strict';
const L = require('./_lib');

module.exports = L.handler(async (req, res) => {
  if (req.method !== 'POST') throw new L.HttpError(405, 'method_not_allowed');
  const { email, password } = L.body(req);
  const e = String(email || '').trim().toLowerCase();
  if (!L.isEmail(e) || !password) throw new L.HttpError(400, 'bad_request', 'Email and password are required.');
  if (await L.overLimit('login:' + L.clientIp(req), 20, 900)) throw new L.HttpError(429, 'rate_limited', 'Too many attempts. Try again in 15 minutes.');

  const staff = L.staffAccounts().find(u => u.email === e && L.safeEqual(u.password, password));
  if (staff) {
    const user = { email: staff.email, name: staff.name, role: staff.role };
    return res.json({ ...user, token: L.signToken({ e: user.email, r: user.role, n: user.name }) });
  }

  const key = L.emailKey(e);
  const [doc, stored] = await Promise.all([L.getDoc('students', key), L.redis('HGET', 'vl:pw', key)]);
  if (doc && L.checkPassword(password, stored)) {
    const user = { email: e, name: doc.name || e, role: 'student' };
    return res.json({ ...user, token: L.signToken({ e, r: 'student', n: user.name }) });
  }
  throw new L.HttpError(401, 'wrong_credentials', 'Wrong email or password.');
});
