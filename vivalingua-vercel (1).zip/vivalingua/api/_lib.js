// Shared helpers for the VivaLingua serverless functions (Vercel, Node 18+).
// No npm packages: Redis is reached over Upstash's REST API and tokens are
// signed with Node's built-in crypto.
'use strict';
const crypto = require('crypto');

const REDIS_URL = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
const REDIS_TOKEN = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;

class HttpError extends Error {
  constructor(status, code, message) { super(message || code); this.status = status; this.code = code; }
}

async function redis(...cmd) {
  if (!REDIS_URL || !REDIS_TOKEN) throw new HttpError(500, 'db_not_configured', 'The database is not connected yet. Add Upstash Redis in Vercel → Storage.');
  const r = await fetch(REDIS_URL, {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + REDIS_TOKEN, 'Content-Type': 'application/json' },
    body: JSON.stringify(cmd.map(String)),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || data.error) throw new HttpError(502, 'db_error', data.error || 'Database request failed');
  return data.result;
}

// ---- collections: one Redis hash per collection, field = doc id, value = JSON
const COLLECTIONS = ['students', 'submissions', 'progress', 'certificates'];
const colKey = col => 'vl:col:' + col;
async function getDoc(col, id) {
  const raw = await redis('HGET', colKey(col), id);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch (e) { return null; }
}
async function listDocs(col) {
  const flat = (await redis('HGETALL', colKey(col))) || [];
  const out = [];
  for (let i = 0; i < flat.length; i += 2) {
    try { out.push({ id: flat[i], data: JSON.parse(flat[i + 1]) }); } catch (e) {}
  }
  return out;
}
const putDoc = (col, id, data) => redis('HSET', colKey(col), id, JSON.stringify(data));
const delDoc = (col, id) => redis('HDEL', colKey(col), id);

// ---- passwords (scrypt), stored apart from the student documents
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.scryptSync(String(pw), salt, 32).toString('hex');
}
function checkPassword(pw, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  const test = crypto.scryptSync(String(pw), salt, 32);
  const want = Buffer.from(hash, 'hex');
  return want.length === test.length && crypto.timingSafeEqual(want, test);
}
function newPassword() {
  const alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
  let s = '';
  for (const b of crypto.randomBytes(8)) s += alphabet[b % alphabet.length];
  return s;
}
function safeEqual(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

// ---- signed session tokens
function secret() {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 16) throw new HttpError(500, 'not_configured', 'SESSION_SECRET is missing (use at least 16 characters).');
  return s;
}
const b64 = s => Buffer.from(s).toString('base64url');
function signToken(payload, days = 30) {
  const body = b64(JSON.stringify({ ...payload, exp: Date.now() + days * 864e5 }));
  const sig = crypto.createHmac('sha256', secret()).update(body).digest('base64url');
  return body + '.' + sig;
}
function readToken(req) {
  const h = req.headers.authorization || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!t.includes('.')) return null;
  const [body, sig] = t.split('.');
  const want = crypto.createHmac('sha256', secret()).update(body).digest('base64url');
  if (!safeEqual(sig, want)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    return p.exp > Date.now() ? p : null;
  } catch (e) { return null; }
}

const emailKey = email => String(email || '').trim().toLowerCase().replace(/[^a-z0-9_\-.~:@+]/g, '_');
const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v || '').trim());

// ---- staff accounts come from environment variables, never from the browser
function staffAccounts() {
  const list = [];
  if (process.env.ADMIN_PASSWORD) list.push({ email: (process.env.ADMIN_EMAIL || 'enavaspm@gmail.com').toLowerCase(), password: process.env.ADMIN_PASSWORD, name: process.env.ADMIN_NAME || 'Administrador', role: 'admin' });
  // TEACHER_ACCOUNTS: "email:password:Name" entries separated by commas
  String(process.env.TEACHER_ACCOUNTS || '').split(',').map(s => s.trim()).filter(Boolean).forEach(entry => {
    const [email, password, ...name] = entry.split(':');
    if (email && password) list.push({ email: email.trim().toLowerCase(), password: password.trim(), name: name.join(':').trim() || email, role: 'teacher' });
  });
  return list;
}

function clientIp(req) {
  return String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
}
// Fixed-window limit; returns true when the caller is over the limit.
async function overLimit(bucket, max, windowSec) {
  const key = 'vl:rl:' + bucket + ':' + Math.floor(Date.now() / 1000 / windowSec);
  const n = await redis('INCR', key);
  if (n === 1) await redis('EXPIRE', key, windowSec);
  return n > max;
}

function body(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  try { return JSON.parse(req.body || '{}'); } catch (e) { return {}; }
}
function handler(fn) {
  return async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    try {
      await fn(req, res);
    } catch (e) {
      const status = e instanceof HttpError ? e.status : 500;
      if (status === 500) console.error(e);
      res.status(status).json({ error: e.message, code: e.code || 'server_error' });
    }
  };
}

module.exports = {
  HttpError, redis, COLLECTIONS, getDoc, listDocs, putDoc, delDoc,
  hashPassword, checkPassword, newPassword, safeEqual, signToken, readToken,
  emailKey, isEmail, staffAccounts, clientIp, overLimit, body, handler,
};
