// POST /api/plaza { prompt } → the JSON object La Plaza expects
// ({ reply, translation, correction, goals, culture }).
// The Anthropic API key stays here on the server (ANTHROPIC_API_KEY).
'use strict';
const L = require('./_lib');

const PREFIX = 'You are role-playing in a language-learning app.';
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';

module.exports = L.handler(async (req, res) => {
  if (req.method !== 'POST') throw new L.HttpError(405, 'method_not_allowed');
  if (!process.env.ANTHROPIC_API_KEY) throw new L.HttpError(500, 'not_configured', 'ANTHROPIC_API_KEY is missing.');
  const { prompt } = L.body(req);
  if (typeof prompt !== 'string' || !prompt.startsWith(PREFIX) || prompt.length > 15000) throw new L.HttpError(400, 'bad_request');

  // Signed-in students get more turns per hour than visitors.
  const who = L.readToken(req);
  const bucket = who ? 'plaza:u:' + L.emailKey(who.e) : 'plaza:ip:' + L.clientIp(req);
  const max = who ? Number(process.env.PLAZA_LIMIT_STUDENT || 200) : Number(process.env.PLAZA_LIMIT_VISITOR || 30);
  if (await L.overLimit(bucket, max, 3600)) throw new L.HttpError(429, 'rate_limited', 'Too many messages this hour.');

  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: MODEL, max_tokens: 700, messages: [{ role: 'user', content: prompt }] }),
  });
  const data = await r.json().catch(() => ({}));
  if (r.status === 429 || r.status === 529) throw new L.HttpError(429, 'rate_limited');
  if (!r.ok) { console.error('anthropic', r.status, data && data.error); throw new L.HttpError(502, 'ai_error'); }

  const text = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
  const start = text.indexOf('{'), end = text.lastIndexOf('}');
  let out;
  try { out = JSON.parse(text.slice(start, end + 1)); } catch (e) { out = { reply: text.trim() }; }
  res.json({
    reply: String(out.reply || ''), translation: String(out.translation || ''), correction: String(out.correction || ''),
    goals: Array.isArray(out.goals) ? out.goals.map(String) : [], culture: String(out.culture || ''),
  });
});
