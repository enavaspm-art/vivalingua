// GET  /api/data?col=students            → { docs: [{ id, data }] }   (filtered by role)
// GET  /api/data?col=students&id=abc     → { doc }
// POST /api/data { op: set|update|delete, col, id, data }
//
// Rules
//   admin/teacher: full access to every collection.
//   student:       sees and writes only their own records.
//   visitor:       may create a student record (placement test) and see
//                  whether an email already took the test.
'use strict';
const L = require('./_lib');

const PLACEMENT_FIELDS = ['level', 'placementScore', 'placementMax', 'placementTest', 'placementCefr', 'placementWriting', 'track'];
const CREATE_FIELDS = ['name', 'email', 'teacher', 'createdAt', ...PLACEMENT_FIELDS];
const pick = (obj, keys) => Object.fromEntries(Object.entries(obj || {}).filter(([k]) => keys.includes(k)));
const cleanId = id => String(id || '').slice(0, 200);

function ownedBy(col, doc, self) {
  if (!self) return false;
  if (col === 'students' || col === 'progress') return doc.id === self;
  return doc.data && doc.data.studentKey === self; // submissions, certificates
}

module.exports = L.handler(async (req, res) => {
  const who = L.readToken(req);
  const role = who ? who.r : 'visitor';
  const staff = role === 'admin' || role === 'teacher';
  const self = role === 'student' ? L.emailKey(who.e) : null;

  if (req.method === 'GET') {
    const col = String(req.query.col || '');
    if (!L.COLLECTIONS.includes(col)) throw new L.HttpError(400, 'bad_collection');
    if (req.query.id != null) {
      const id = cleanId(req.query.id);
      const data = await L.getDoc(col, id);
      if (!data) return res.json({ doc: null });
      if (staff || ownedBy(col, { id, data }, self)) return res.json({ doc: data });
      if (col === 'students') return res.json({ doc: pick(data, ['placementScore', 'placementMax', 'level']) });
      throw new L.HttpError(403, 'not_allowed');
    }
    if (role === 'visitor') return res.json({ docs: [] });
    const docs = await L.listDocs(col);
    return res.json({ docs: staff ? docs : docs.filter(d => ownedBy(col, d, self)) });
  }

  if (req.method !== 'POST') throw new L.HttpError(405, 'method_not_allowed');
  const { op, col, data } = L.body(req);
  const id = cleanId(L.body(req).id);
  if (!L.COLLECTIONS.includes(col) || !id) throw new L.HttpError(400, 'bad_request');
  if (!['set', 'update', 'delete'].includes(op)) throw new L.HttpError(400, 'bad_op');
  if (JSON.stringify(data || {}).length > 20000) throw new L.HttpError(413, 'too_large');

  const existing = await L.getDoc(col, id);

  // ----- staff
  if (staff) {
    if (op === 'delete') { await L.delDoc(col, id); return res.json({ ok: true }); }
    const next = op === 'update' ? { ...(existing || {}), ...data } : { ...data };
    await L.putDoc(col, id, next);
    const out = { ok: true };
    if (col === 'students' && !existing) out.password = await issuePassword(id);
    return res.json(out);
  }

  // ----- students and visitors
  if (col === 'students') {
    if (op === 'delete') throw new L.HttpError(403, 'not_allowed');
    if (!existing) {
      if (await L.overLimit('signup:' + L.clientIp(req), 10, 3600)) throw new L.HttpError(429, 'rate_limited');
      const rec = { ...pick(data, CREATE_FIELDS), paid: false };
      if (!L.isEmail(rec.email) || L.emailKey(rec.email) !== id) throw new L.HttpError(400, 'bad_email');
      rec.name = String(rec.name || rec.email).slice(0, 120);
      await L.putDoc('students', id, rec);
      const password = await issuePassword(id);
      return res.json({ ok: true, password, token: L.signToken({ e: rec.email, r: 'student', n: rec.name }) });
    }
    // Existing student: only a first placement result may be added.
    if (existing.placementScore != null) throw new L.HttpError(409, 'placement_done', 'This email already took the placement test.');
    const patch = pick(data, PLACEMENT_FIELDS);
    if (!Object.keys(patch).length) return res.json({ ok: true });
    await L.putDoc('students', id, { ...existing, ...patch });
    return res.json({ ok: true });
  }

  if (!self) throw new L.HttpError(401, 'unauthorized', 'Please sign in again.');

  if (col === 'progress' && op === 'set' && id === self) {
    await L.putDoc('progress', id, { completed: Array.isArray(data.completed) ? data.completed.slice(0, 200) : [], updatedAt: new Date().toISOString() });
    return res.json({ ok: true });
  }
  if (col === 'submissions' && op === 'set' && !existing) {
    if (await L.overLimit('sub:' + self, 60, 3600)) throw new L.HttpError(429, 'rate_limited');
    const rec = pick(data, ['studentName', 'lessonIndex', 'lessonTitle', 'track', 'text', 'createdAt']);
    rec.text = String(rec.text || '').slice(0, 4000);
    await L.putDoc('submissions', id, { ...rec, studentKey: self, status: 'pending' });
    return res.json({ ok: true });
  }
  throw new L.HttpError(403, 'not_allowed');
});

async function issuePassword(id) {
  const password = L.newPassword();
  await L.redis('HSET', 'vl:pw', id, L.hashPassword(password));
  return password;
}
