// VivaLingua — single-page app.
// Views: home, login, student, teacher, admin. Data lives in the artifact's
// shared database when the page runs on claude.ai, and falls back to this
// browser's localStorage anywhere else.

const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const emailKey = email => String(email || '').trim().toLowerCase().replace(/[^a-z0-9_\-.~:@+]/g, '_');
const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v || '').trim());
const fmtDate = iso => { try { return new Date(iso).toLocaleDateString(); } catch (e) { return ''; } };
const TOTAL_LESSONS = 25;

const TEACHERS = [
  { name: 'Susana', specialty: 'Inglés general' },
  { name: 'José', specialty: 'Conversación' },
];

// Sign-in is checked on the server (api/login.js). Staff passwords live in
// Vercel environment variables; each student gets a personal password from the
// server when their record is created, shown once on screen.
const PASSWORD_PLACEHOLDER = '(la que recibiste al inscribirte / the one you received when you enrolled)';
let STUDENT_PASSWORD = PASSWORD_PLACEHOLDER;
window.VL_onStudentPassword = pw => { STUDENT_PASSWORD = pw; };
const DEMO_USERS = [];

// ---------------------------------------------------------------- storage
function lsGet(key) { try { return localStorage.getItem(key); } catch (e) { return null; } }
function lsSet(key, val) { try { localStorage.setItem(key, val); } catch (e) {} }
function lsDel(key) { try { localStorage.removeItem(key); } catch (e) {} }
function ssGet(key) { try { return sessionStorage.getItem(key); } catch (e) { return null; } }
function ssSet(key, val) { try { sessionStorage.setItem(key, val); } catch (e) {} }
function ssDel(key) { try { sessionStorage.removeItem(key); } catch (e) {} }

const Store = (() => {
  let db = null;
  let resolved = false;
  const subs = {};
  const cache = {};
  const unsubs = {};

  const localKey = col => 'navasData_' + col;
  const readLocal = col => { try { return JSON.parse(lsGet(localKey(col))) || {}; } catch (e) { return {}; } };
  const writeLocal = (col, obj) => lsSet(localKey(col), JSON.stringify(obj));
  const loadLocal = col => { cache[col] = Object.entries(readLocal(col)).map(([id, d]) => ({ id, ...d })); };
  const emit = col => (subs[col] || []).forEach(cb => cb(cache[col] || []));

  function attach(col) {
    if (db) {
      if (unsubs[col]) return;
      unsubs[col] = db.collection(col).onSnapshot(
        snap => { cache[col] = snap.docs.map(d => ({ id: d.id, ...d.data() })); emit(col); },
        err => console.warn('db subscription ended', col, err && err.code)
      );
    } else {
      loadLocal(col);
      emit(col);
    }
  }

  const useDb = window.claude && typeof window.claude.use === 'function'
    ? window.claude.use('db').catch(() => null)
    : Promise.resolve(null);

  const ready = useDb.then(d => {
    db = d;
    resolved = true;
    Object.keys(subs).forEach(attach);
    return d;
  });

  function subscribe(col, cb) {
    (subs[col] = subs[col] || []).push(cb);
    if (cache[col]) cb(cache[col]);
    if (resolved) attach(col);
  }

  async function set(col, id, data) {
    await ready;
    if (db) return db.collection(col).doc(id).set(data);
    const all = readLocal(col); all[id] = data; writeLocal(col, all); loadLocal(col); emit(col);
  }
  async function update(col, id, data) {
    await ready;
    if (db) return db.collection(col).doc(id).update(data);
    const all = readLocal(col); all[id] = { ...(all[id] || {}), ...data }; writeLocal(col, all); loadLocal(col); emit(col);
  }
  async function remove(col, id) {
    await ready;
    if (db) return db.collection(col).doc(id).delete();
    const all = readLocal(col); delete all[id]; writeLocal(col, all); loadLocal(col); emit(col);
  }
  async function add(col, data) {
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    await set(col, id, data);
    return id;
  }
  // Read one document straight from the store (not the live cache), for
  // decisions that must not act on a cache that hasn't loaded yet.
  async function fetch(col, id) {
    await ready;
    if (db) { const snap = await db.collection(col).doc(id).get(); return snap.exists ? { id, ...snap.data() } : null; }
    const d = readLocal(col)[id]; return d ? { id, ...d } : null;
  }
  const get = col => cache[col] || [];
  const find = (col, id) => get(col).find(d => d.id === id);

  return { subscribe, set, update, remove, add, get, find, fetch, ready, isShared: () => !!db };
})();

async function save(promise, okMsg) {
  try {
    await promise;
    if (okMsg) showToast(okMsg, 'success');
    return true;
  } catch (e) {
    const code = e && e.code;
    const msg = code === 'quota_exceeded' ? 'La base de datos está llena.' : 'No se pudo guardar. Inténtalo de nuevo.';
    showToast(msg, 'error');
    console.warn('save failed', e);
    return false;
  }
}

// ---------------------------------------------------------------- UI helpers
function showToast(message, type) {
  let toast = document.getElementById('navasToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'navasToast';
    toast.className = 'toast';
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.className = 'toast show' + (type ? ' toast-' + type : '');
  clearTimeout(toast._hideTimer);
  toast._hideTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}

function openModal(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.add('active');
  const focusable = el.querySelector('input, select, textarea, button:not(.close)');
  if (focusable) focusable.focus();
}
function closeModal(id) { const el = document.getElementById(id); if (el) el.classList.remove('active'); }

document.addEventListener('click', e => {
  if (e.target.classList && e.target.classList.contains('modal-overlay')) e.target.classList.remove('active');
  const closer = e.target.closest('[data-close]');
  if (closer) closeModal(closer.dataset.close);
  const go = e.target.closest('[data-go]');
  if (go) { e.preventDefault(); showView(go.dataset.go); }
  const pageBtn = e.target.closest('.nav-btn[data-page]');
  if (pageBtn) showPage(pageBtn.dataset.page);
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') $$('.modal-overlay.active').forEach(m => m.classList.remove('active'));
});

// In-page replacement for the browser's confirm dialog, which embedded
// pages may not be allowed to show.
function askConfirm(message) {
  return new Promise(resolve => {
    $('#confirmText').textContent = message;
    const done = val => { closeModal('confirmModal'); $('#confirmYes').onclick = $('#confirmNo').onclick = null; resolve(val); };
    $('#confirmYes').onclick = () => done(true);
    $('#confirmNo').onclick = () => done(false);
    openModal('confirmModal');
  });
}

// ---------------------------------------------------------------- language
const getLang = () => lsGet('navasSiteLang') || 'es';
const setLang = lang => lsSet('navasSiteLang', lang);
const tr = (es, en) => (getLang() === 'es' ? es : en);

function applyI18n() {
  const lang = getLang();
  const dict = { ...SITE_TEXT[lang], ...APP_TEXT[lang] };
  document.documentElement.lang = lang;
  $$('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key] !== undefined) el.innerHTML = dict[key];
  });
  $('#langToggle').textContent = SITE_TEXT[lang].langLabel;
  renderPromo();
}

function renderPromo() {
  $('#promoTitle').textContent = tr('Practica conversando en la Plaza.', 'Practice real conversations in the Plaza.');
  $('#promoText').textContent = tr(
    'Entra a un restaurante, un aeropuerto o una entrevista de trabajo y conversa con un compañero de IA que actúa la escena contigo, te corrige y te enseña costumbres del país.',
    'Step into a restaurant, an airport or a job interview and talk with an AI partner who acts out the scene, corrects you and shares local customs.');
  $('#promoBtn').textContent = tr('Entrar a la Plaza', 'Enter the Plaza');
  $('#promoDemoLabel').textContent = tr('EJEMPLO · RESTAURANTE', 'EXAMPLE · RESTAURANT');
}

function toggleLang() {
  setLang(getLang() === 'es' ? 'en' : 'es');
  applyI18n();
  if (window.PlazaApp) window.PlazaApp.followSiteLanguage(getLang());
  renderQuiz();
  renderAll();
}
$('#langToggle').addEventListener('click', toggleLang);
$('#registerLangSwitch').addEventListener('click', toggleLang);

// ---------------------------------------------------------------- session & views
function getSession() {
  if (!window.VL || !VL.hasToken()) return null;
  const raw = lsGet('navasAcademySession') || ssGet('navasAcademySession');
  try { return raw ? JSON.parse(raw) : null; } catch (e) { return null; }
}
function setSession(s, remember) {
  lsDel('navasAcademySession'); ssDel('navasAcademySession');
  (remember ? lsSet : ssSet)('navasAcademySession', JSON.stringify(s));
}
function logout() {
  if (window.VL) VL.logout();
  lsDel('navasAcademySession'); ssDel('navasAcademySession');
  showView('login');
}
$('#navLogout').addEventListener('click', logout);
$('#logoLink').addEventListener('click', e => { e.preventDefault(); const s = getSession(); showView(s ? s.role : 'home'); });

let currentView = 'home';
const DEFAULT_PAGE = { student: 'dashboard', teacher: 'tdash', admin: 'adash' };

function showView(view) {
  const session = getSession();
  if (['student', 'teacher', 'admin'].includes(view) && (!session || session.role !== view)) view = 'login';
  currentView = view;
  $$('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + view));
  const inApp = ['student', 'teacher', 'admin'].includes(view);
  if (view === 'plaza' && window.PlazaApp) window.PlazaApp.show();
  $('#navPortal').hidden = !(view === 'plaza' && session);
  if (session) { $('#navPortal').dataset.go = session.role; $('#navPortal').textContent = tr('Mi portal', 'My portal'); }
  $('#publicLinks').hidden = view !== 'home';
  $('#publicLinks').style.display = view === 'home' ? '' : 'none';
  $('#navCta').hidden = view !== 'home';
  $('#navBackHome').hidden = !(view === 'login' || view === 'plaza');
  $('#navLogout').hidden = !inApp;
  $('#navUser').hidden = !inApp;
  $('#langToggle').hidden = view === 'teacher' || view === 'admin' || view === 'plaza';
  if (inApp) {
    $('#navUser').textContent = session.name;
    showPage(DEFAULT_PAGE[view]);
  }
  renderAll();
  window.scrollTo({ top: 0 });
}

function showPage(id) {
  const view = document.getElementById('view-' + currentView);
  if (!view) return;
  view.querySelectorAll('.page').forEach(p => p.classList.toggle('active', p.id === id));
  view.querySelectorAll('.nav-btn').forEach(b => {
    const on = b.dataset.page === id;
    b.classList.toggle('active', on);
    if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ---------------------------------------------------------------- derived data
const students = () => Store.get('students').slice().sort((a, b) => String(a.name).localeCompare(String(b.name)));
const submissions = () => Store.get('submissions').slice().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
const certificates = () => Store.get('certificates').slice().sort((a, b) => String(b.issuedAt).localeCompare(String(a.issuedAt)));
const completedFor = key => { const p = Store.find('progress', key); return Array.isArray(p && p.completed) ? p.completed : []; };
const pctFor = key => Math.round((completedFor(key).length / TOTAL_LESSONS) * 100);
const avg = arr => (arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : 0);
const stat = (value, label) => `<div class="stat"><strong>${esc(value)}</strong><span>${esc(label)}</span></div>`;
const empty = text => `<div class="empty">${esc(text)}</div>`;

// ---------------------------------------------------------------- owner email alerts
// New enrollments and placement results are emailed to the school owner through
// FormSubmit (formsubmit.co), which needs no server. The very first message makes
// FormSubmit send an activation email to this address; alerts start once it is confirmed.
const OWNER_EMAIL = 'enavaspm@gmail.com';
function notifyOwner(subject, fields) {
  try {
    fetch('https://formsubmit.co/ajax/' + OWNER_EMAIL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ _subject: subject, _template: 'table', _captcha: 'false', ...fields }),
    }).catch(() => {});
  } catch (e) {}
}
function alertEnrollment(record, isNew) {
  const email = String(record.email || '').toLowerCase();
  if (DEMO_USERS.some(u => u.email === email)) return;
  const hasTest = record.placementScore != null;
  if (!isNew && !hasTest) return;
  const fields = { Alumno: record.name || email, Email: email, Nivel: record.level || '' };
  if (hasTest) {
    fields['Examen'] = record.placementTest || (record.track === 'es' ? 'Examen de inglés' : 'Examen de español');
    fields['Resultado'] = record.placementScore + (record.placementMax ? ' / ' + record.placementMax : '') + (record.placementCefr ? ' (' + record.placementCefr + ')' : '');
    if (record.placementWriting) fields['Texto escrito'] = record.placementWriting;
  }
  fields['Fecha'] = new Date().toLocaleString('es');
  const who = record.name || email;
  notifyOwner(isNew ? (hasTest ? 'VivaLingua: nueva inscripción y examen de nivel, ' + who : 'VivaLingua: nueva inscripción, ' + who)
    : 'VivaLingua: nuevo resultado de examen de nivel, ' + who, fields);
}

async function ensureStudentRecord(name, email, extra) {
  const key = emailKey(email);
  const existing = await Store.fetch('students', key);
  if (existing) {
    if (extra && Object.keys(extra).length) {
      const r = await Store.update('students', key, extra);
      if (extra.placementScore != null) alertEnrollment({ ...existing, ...extra }, false);
      return r;
    }
    return;
  }
  const record = {
    name: name || email, email: email.trim().toLowerCase(), level: 'Nivel 1', teacher: TEACHERS[0].name,
    paid: false, createdAt: new Date().toISOString(), ...(extra || {}),
  };
  const r = await Store.set('students', key, record);
  alertEnrollment(record, true);
  return r;
}

// ---------------------------------------------------------------- home: registration + placement
// One attempt per student: the test needs a name and email, and an email that
// already has a placement result cannot take it again.
async function placementGuard() {
  const box = $('#placementResult');
  const btn = document.querySelector('#quizForm button[type=submit]');
  const name = $('#regName').value.trim();
  const email = $('#regEmail').value.trim();
  if (!name || !isEmail(email)) {
    box.innerHTML = `<span class="status status-red">${esc(tr('Escribe tu nombre y tu email arriba antes de enviar el examen. Solo tienes una oportunidad.', 'Enter your name and email above before you submit the test. You only get one try.'))}</span>`;
    $('#regName').focus();
    return true;
  }
  let s = null;
  try { s = await Store.fetch('students', emailKey(email)); } catch (err) { s = null; }
  if (s && s.placementScore != null) {
    const res = s.placementScore + (s.placementMax ? '/' + s.placementMax : '');
    box.innerHTML = `<div class="card" style="background:var(--primary-soft)"><strong>${esc(tr('Ya hiciste el examen de nivel.', 'You already took the placement test.'))}</strong>
      <p class="small" style="margin:8px 0">${esc(tr('Solo hay una oportunidad por alumno. Tu resultado fue ' + res + ' (' + (s.level || '') + '). Si crees que hay un error, escríbenos.', 'Each student gets one try. Your result was ' + res + ' (' + (s.level || '') + '). If you think there is a mistake, contact us.'))}</p></div>`;
    if (btn) btn.disabled = true;
    return true;
  }
  if (btn) btn.disabled = true;
  return false;
}
function renderQuiz() {
  const questions = QUIZ[getLang()];
  $('#quiz').innerHTML = questions.map((q, i) => `
    <fieldset>
      <legend>${i + 1}. ${esc(q[0])}</legend>
      <div class="quiz-options">
        ${q[1].map((a, j) => `<label><input type="radio" name="q${i}" value="${j}" style="width:auto;margin-right:8px"> ${esc(a)}</label>`).join('')}
      </div>
    </fieldset>`).join('');
  $('#placementResult').innerHTML = '';
}

$('#regStart').addEventListener('click', () => {
  const name = $('#regName').value.trim();
  const email = $('#regEmail').value.trim();
  if (!name || !isEmail(email)) {
    $('#regMessage').innerHTML = `<span class="status status-red">${esc(tr('Escribe tu nombre y un email válido.', 'Enter your name and a valid email.'))}</span>`;
    return;
  }
  $('#regMessage').innerHTML = `<span class="status status-green">${esc(tr('¡Listo! Ahora responde el examen.', 'Great! Now take the test.'))}</span>`;
  $('#placement').scrollIntoView({ behavior: 'smooth' });
});

$('#quizForm').addEventListener('submit', async e => {
  e.preventDefault();
  const lang = getLang();
  const questions = QUIZ[lang];
  const text = SITE_TEXT[lang];
  let score = 0, answered = 0;
  questions.forEach((q, i) => {
    const el = document.querySelector(`input[name=q${i}]:checked`);
    if (el) { answered++; if (+el.value === q[2]) score++; }
  });
  if (answered < questions.length) {
    $('#placementResult').innerHTML = `<span class="status status-red">${esc(text['placement.incomplete'])}</span>`;
    return;
  }
  const levelNum = score <= 2 ? 1 : score <= 4 ? 2 : 3;
  const levelLabel = text['placement.level' + levelNum];
  const name = $('#regName').value.trim();
  const email = $('#regEmail').value.trim();
  let action;
  if (name && isEmail(email)) {
    const ok = await save(ensureStudentRecord(name, email, { level: 'Nivel ' + levelNum, placementScore: score, track: lang }));
    if (ok) {
      action = `<p class="small" style="margin:10px 0">${esc(tr('Tu cuenta está creada. Para volver a entrar usa tu email y la contraseña', 'Your account is ready. To sign in again use your email and the password'))} <strong>${STUDENT_PASSWORD}</strong>. ${esc(tr('Anótala ahora: no se vuelve a mostrar.', 'Write it down now: it is not shown again.'))}</p>
        <button class="btn btn-primary" id="enterPortal">${esc(tr('Entrar a mi portal', 'Go to my portal'))}</button>`;
    }
  }
  if (!action) {
    action = `<p class="small" style="margin:10px 0">${esc(tr('Completa tu nombre y email arriba para guardar tu resultado y crear tu cuenta.', 'Fill in your name and email above to save your result and create your account.'))}</p>
      <a class="btn btn-secondary" href="#register">${esc(tr('Crear mi cuenta', 'Create my account'))}</a>`;
  }
  $('#placementResult').innerHTML = `<div class="card" style="background:var(--primary-soft)"><strong>${esc(text['placement.resultPrefix'])} ${esc(levelLabel)}</strong> <span class="small">(${score}/5)</span>${action}</div>`;
  const enter = $('#enterPortal');
  if (enter) enter.addEventListener('click', () => {
    setSession({ email: email.toLowerCase(), name, role: 'student', loginTime: new Date().toISOString() }, true);
    showView('student');
  });
});

// ---------------------------------------------------------------- login
$('#loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  const email = $('#loginEmail').value.trim().toLowerCase();
  const password = $('#loginPassword').value;
  const btn = $('#loginForm button[type=submit]');
  btn.disabled = true;
  let user = null, problem = '';
  try { user = await VL.login(email, password, $('#remember').checked); }
  catch (err) {
    problem = err.code === 'wrong_credentials' ? tr('Correo o contraseña incorrectos.', 'Wrong email or password.')
      : err.code === 'rate_limited' ? tr('Demasiados intentos. Espera 15 minutos.', 'Too many attempts. Wait 15 minutes.')
      : tr('No se pudo conectar. Inténtalo de nuevo.', 'Could not connect. Please try again.');
  }
  btn.disabled = false;
  if (!user) {
    $('#loginMessage').innerHTML = `<span class="status status-red">${esc(problem)}</span>`;
    return;
  }
  setSession({ email: user.email, name: user.name, role: user.role, loginTime: new Date().toISOString() }, $('#remember').checked);
  $('#loginMessage').innerHTML = '';
  $('#loginForm').reset();
  showView(user.role);
});

function renderLoginHelp() {
  $('#loginHelp').textContent = tr(
    '¿Te registraste con el examen de nivel? Entra con tu email y la contraseña que recibiste. Si la olvidaste, escríbenos.',
    'Signed up through the placement test? Log in with your email and the password you received. If you forgot it, contact us.');
}

// ---------------------------------------------------------------- listen (text to speech)
function sayText(text, langCode) {
  try {
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = langCode;
    const v = speechSynthesis.getVoices().find(x => x.lang && x.lang.toLowerCase().startsWith(langCode.slice(0, 2).toLowerCase()));
    if (v) u.voice = v;
    u.rate = 0.9;
    speechSynthesis.speak(u);
  } catch (e) {}
}
const canSay = () => 'speechSynthesis' in window;
const sayBtn = (text, lang) => canSay() ? `<button type="button" class="say-btn" data-say="${esc(text)}" data-say-lang="${esc(SPEECH_LANG[lang])}" aria-label="${esc(tr('Escuchar', 'Listen'))}: ${esc(text)}">🔊</button>` : '';
document.addEventListener('click', e => {
  const b = e.target.closest('[data-say]');
  if (b) sayText(b.dataset.say, b.dataset.sayLang);
});

// ---------------------------------------------------------------- student
let activeLesson = null;

function watercolorBanner(title, intro) {
  return `<div class="watercolor-banner"><img src="assets/images/navas-watercolor-family.jpeg" alt="Watercolor artwork of the Navas family"><div class="watercolor-copy"><div class="eyebrow">NAVAS FAMILY STORY</div><h2>${esc(title)}</h2><p>${esc(intro)}</p></div></div>`;
}

const lessonLevel = i => LESSON_LEVELS.find(l => i >= l.from && i <= l.to) || LESSON_LEVELS[0];
// The student's lesson level: Nivel 1 → beginner lessons; Nivel 2 or 3 → intermediate lessons.
function studentLessonLevel(key) {
  const s = Store.find('students', key);
  const n = parseInt(String((s && s.level) || '').replace(/\D/g, ''), 10) || 1;
  return LESSON_LEVELS.find(l => l.num === Math.min(n, LESSON_LEVELS.length)) || LESSON_LEVELS[0];
}
function nextLessonIndex(done, startAt = 0) {
  for (let i = startAt; i < TOTAL_LESSONS; i++) if (!done.includes(i)) return i;
  for (let i = 0; i < startAt; i++) if (!done.includes(i)) return i;
  return TOTAL_LESSONS - 1;
}

function renderStudent() {
  const session = getSession();
  if (!session || session.role !== 'student') return;
  const lang = getLang();
  const key = emailKey(session.email);
  const done = completedFor(key);
  const mySubs = submissions().filter(s => s.studentKey === key);
  const pct = pctFor(key);
  const myLevel = studentLessonLevel(key);
  if (activeLesson === null) activeLesson = nextLessonIndex(done, myLevel.from);

  $('#helloWord').textContent = tr('Hola', 'Hi');
  $('#studentGreeting').textContent = String(session.name).split(' ')[0];
  $('#studentStats').innerHTML =
    stat(pct + '%', tr('Progreso', 'Progress')) +
    stat(done.length, tr('Lecciones completadas', 'Lessons completed')) +
    stat(mySubs.length, tr('Misiones enviadas', 'Missions sent')) +
    stat(Math.floor(done.length / 5), tr('Insignias', 'Badges'));

  renderStudentPlaza();

  const next = nextLessonIndex(done, myLevel.from);
  const sc = LEVEL1_SCENARIOS[lang][next];
  $('#continueLessonTitle').textContent = `${next + 1} · ${sc[0]}`;
  $('#continueLessonDesc').textContent = sc[1];

  $('#studentLessons').innerHTML = LESSON_LEVELS.map(lv => {
    const rows = LEVEL1_LESSONS[lang].slice(lv.from, lv.to + 1).map((l, k) => {
      const i = lv.from + k;
      const isDone = done.includes(i);
      return `<div class="lesson-row${isDone ? ' done' : ''}" data-lesson="${i}" role="button" tabindex="0">
      <div class="lesson-icon" aria-hidden="true">${isDone ? '✓' : '🎨'}</div>
      <div><strong>${i + 1}. ${esc(l)}</strong><div class="small">${esc(tr('Escenario con la Familia Navas', 'Navas Family scenario'))}</div></div>
      <span class="status ${isDone ? 'status-green' : 'status-blue'}">${isDone ? 'OK' : '→'}</span></div>`;
    }).join('');
    const doneHere = done.filter(i => i >= lv.from && i <= lv.to).length;
    const mine = lv.num === myLevel.num ? ` <span class="status status-blue">${esc(tr('Tu nivel', 'Your level'))}</span>` : '';
    return `<div class="level-head"><div class="eyebrow" style="margin:0">${esc(tr('NIVEL ', 'LEVEL ') + lv.num)}</div><h2>${esc(tr(lv.es, lv.en))}${mine}</h2><span class="small">${esc(tr(`Lecciones ${lv.from + 1}–${lv.to + 1} · ${doneHere}/${lv.to - lv.from + 1} completadas`, `Lessons ${lv.from + 1}–${lv.to + 1} · ${doneHere}/${lv.to - lv.from + 1} completed`))}</span></div>${rows}`;
  }).join('');

  $('#navMySubs').textContent = tr('📝 Mis misiones', '📝 My missions');
  $('#mySubsEyebrow').textContent = tr('MISIONES', 'MISSIONS');
  $('#mySubsTitle').textContent = tr('Mis misiones', 'My missions');
  $('#mySubsText').textContent = tr('Aquí ves tus entregas y los comentarios de tu profesor.', 'Your submissions and your teacher’s feedback.');
  $('#mySubsList').innerHTML = mySubs.length ? mySubs.map(subCardForStudent).join('') : empty(tr('Todavía no enviaste ninguna misión.', 'You haven’t sent any missions yet.'));

  renderLessonDetail();
  renderStories();
}

function renderStories() {
  const lang = getLang();
  const t = lang === 'es' ? 1 : 0; // English column for the English track, Spanish column for the Spanish track
  const showTr = $('#storiesShowTr').checked;
  $('#navStories').textContent = tr('📖 Historias', '📖 Stories');
  $('#storiesEyebrow').textContent = tr('HISTORIAS', 'STORIES');
  $('#storiesTitle').textContent = tr('Historias de la familia Navas', 'Navas Family stories');
  $('#storiesText').textContent = tr('Lee y escucha historias cortas con José, Susana, Isabel y Max. Toca 🔊 para oír cada frase.', 'Read and listen to short stories with José, Susana, Isabel and Max. Tap 🔊 to hear each line.');
  $('#storiesTrLabel').textContent = tr('Mostrar traducción', 'Show translation');
  $('#storiesList').innerHTML = STORIES.map(st => {
    const lv = LESSON_LEVELS.find(l => l.num === st.level) || LESSON_LEVELS[0];
    const lines = st.lines.map(pair => `<div class="story-line"><div><div>${esc(pair[t])}</div>${showTr ? `<div class="small">${esc(pair[1 - t])}</div>` : ''}</div>${sayBtn(pair[t], lang)}</div>`).join('');
    const full = st.lines.map(p => p[t]).join(' ');
    return `<details class="card story-card"><summary><span class="eyebrow" style="margin:0">${esc(tr('NIVEL ', 'LEVEL ') + lv.num + ' · ' + tr(lv.es, lv.en).toUpperCase())}</span><h3>${esc(st.title[t])}</h3><span class="small">${esc(st.title[1 - t])}</span></summary>
      ${canSay() ? `<button type="button" class="btn btn-secondary btn-small" data-say="${esc(full)}" data-say-lang="${esc(SPEECH_LANG[lang])}" style="margin:12px 0">🔊 ${esc(tr('Escuchar toda la historia', 'Listen to the whole story'))}</button>` : ''}${lines}</details>`;
  }).join('');
}
$('#storiesShowTr').addEventListener('change', () => {
  const open = [...$$('#storiesList details')].map(d => d.open);
  renderStories();
  $$('#storiesList details').forEach((d, i) => { d.open = !!open[i]; });
});

function renderStudentPlaza() {
  const st = window.PlazaApp ? window.PlazaApp.stats() : null;
  $('#studentPlazaTitle').textContent = tr('Practica conversando', 'Practice conversations');
  $('#studentPlazaBtn').textContent = tr('Entrar a la Plaza', 'Enter the Plaza');
  $('#studentPlazaText').textContent = !st ? '' : st.mastered
    ? tr(`Has dominado ${st.mastered} de ${st.total} situaciones en ${st.langName}.`, `You've mastered ${st.mastered} of ${st.total} situations in ${st.langName}.`) + (st.next ? tr(` Siguiente: ${st.next}.`, ` Next: ${st.next}.`) : '')
    : tr('Conversa con un compañero de IA en 8 lugares reales: restaurante, aeropuerto, médico y más.', 'Talk with an AI partner in 8 real places: restaurant, airport, doctor and more.');
}
document.addEventListener('plaza:change', () => { if (currentView === 'student') renderStudentPlaza(); });

function subCardForStudent(s) {
  const reviewed = s.status === 'reviewed';
  return `<div class="sub-card">
    <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><strong>${esc((s.lessonIndex + 1) + ' · ' + s.lessonTitle)}</strong>
    <span class="status ${reviewed ? 'status-green' : 'status-orange'}">${reviewed ? esc(tr('Revisada', 'Reviewed')) + ' · ' + esc(s.score) + '/4' : esc(tr('Pendiente', 'Pending'))}</span></div>
    <div class="small">${esc(fmtDate(s.createdAt))}</div>
    <div class="sub-text">${esc(s.text)}</div>
    ${reviewed && s.comments ? `<div><strong>${esc(tr('Comentarios', 'Feedback'))}:</strong> ${esc(s.comments)}</div>` : ''}
  </div>`;
}

function renderLessonDetail() {
  const session = getSession();
  if (!session || session.role !== 'student') return;
  const lang = getLang();
  const key = emailKey(session.email);
  const done = completedFor(key);
  const index = activeLesson ?? 0;
  const [title, scene, s1, l1, s2, l2] = LEVEL1_SCENARIOS[lang][index];
  const lv = lessonLevel(index);
  $('#lessonEyebrow').textContent = tr(`NIVEL ${lv.num} · ${lv.es.toUpperCase()} · LECCIÓN `, `LEVEL ${lv.num} · ${lv.en.toUpperCase()} · LESSON `) + (index + 1);
  $('#lessonTitle').textContent = title;
  $('#lessonIntro').textContent = scene;
  $('#lessonWatercolor').innerHTML = watercolorBanner(title, scene);
  $('#lessonStory').innerHTML = `<div class="scenario-card"><div class="scene"><strong>${esc(tr('Escenario', 'Scenario'))}:</strong> ${esc(scene)}</div><div class="dialogue-line"><strong>${esc(s1)}:</strong> ${esc(l1)} ${sayBtn(l1, lang)}</div><div class="dialogue-line"><strong>${esc(s2)}:</strong> ${esc(l2)} ${sayBtn(l2, lang)}</div></div>`;
  const gr = GRAMMAR[lang] && GRAMMAR[lang][index];
  $('#grammarHeading').textContent = tr('Gramática', 'Grammar');
  $('#lessonGrammar').innerHTML = gr ? `<h3 class="grammar-title">${esc(gr.t)}</h3><p class="grammar-note">${esc(gr.n)}</p>
    <div class="grammar-ex">${gr.ex.map(([a, b]) => `<div class="grammar-row"><div><strong>${esc(a)}</strong><div class="small">${esc(b)}</div></div>${sayBtn(a, lang)}</div>`).join('')}</div>` : '';
  $('#lessonVocab').innerHTML = [l1, l2].map(line => `<div class="course-card"><strong>${esc(line)}</strong> ${sayBtn(line, lang)}<p class="small">${esc(tr('Practica esta frase en voz alta.', 'Practice this phrase out loud.'))}</p></div>`).join('') +
    `<div class="course-card"><strong>${esc(tr('Tu turno', 'Your turn'))}</strong><p class="small">${esc(tr('Cambia un detalle y crea tu propia frase.', 'Change one detail and make your own sentence.'))}</p></div>`;
  $('#missionPrompt').textContent = tr(`Representa la escena de “${title}”. Escribe tu versión de la conversación usando las frases del diálogo.`, `Role-play the “${title}” scene. Write your version of the conversation using the dialogue phrases.`);
  $('#missionInput').placeholder = tr('Escribe aquí tu versión de la conversación...', 'Write your version of the conversation here...');
  $('#missionCtaBtn').textContent = tr('Enviar misión', 'Send mission');
  $('#lessonProgressTitle').textContent = `${index + 1} · ${title}`;
  const pct = pctFor(key);
  $('#courseProgressFill').style.width = pct + '%';
  $('#courseProgressLabel').textContent = tr(`Curso: ${done.length}/${TOTAL_LESSONS} lecciones (${pct}%)`, `Course: ${done.length}/${TOTAL_LESSONS} lessons (${pct}%)`);
  const isDone = done.includes(index);
  $('#completeCtaBtn').textContent = isDone ? tr('✓ Lección completada', '✓ Lesson completed') : tr('Completar lección', 'Complete lesson');
  $('#completeCtaBtn').disabled = isDone;
  const lessonSubs = submissions().filter(s => s.studentKey === key && s.lessonIndex === index);
  $('#lessonSubs').innerHTML = lessonSubs.length ? `<div class="eyebrow" style="margin-top:6px">${esc(tr('TUS ENTREGAS', 'YOUR SUBMISSIONS'))}</div>` + lessonSubs.map(subCardForStudent).join('') : '';
}

function openLesson(i) {
  activeLesson = i;
  $('#missionInput').value = '';
  renderLessonDetail();
  showPage('lesson');
}

$('#studentLessons').addEventListener('click', e => { const row = e.target.closest('[data-lesson]'); if (row) openLesson(+row.dataset.lesson); });
$('#studentLessons').addEventListener('keydown', e => {
  const row = e.target.closest('[data-lesson]');
  if (row && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); openLesson(+row.dataset.lesson); }
});
$('#continueBtn').addEventListener('click', () => openLesson(nextLessonIndex(completedFor(emailKey(getSession().email)))));

$('#completeCtaBtn').addEventListener('click', async () => {
  const session = getSession();
  const key = emailKey(session.email);
  const done = completedFor(key);
  if (done.includes(activeLesson)) return;
  const completed = [...done, activeLesson].sort((a, b) => a - b);
  const ok = await save(Store.set('progress', key, { completed, updatedAt: new Date().toISOString() }), tr('¡Lección completada!', 'Lesson completed!'));
  if (ok) renderStudent();
});

$('#missionCtaBtn').addEventListener('click', async () => {
  const text = $('#missionInput').value.trim();
  if (text.length < 5) { showToast(tr('Escribe tu práctica antes de enviarla.', 'Write your practice before sending it.'), 'error'); return; }
  const session = getSession();
  const lang = getLang();
  const btn = $('#missionCtaBtn');
  btn.disabled = true;
  const ok = await save(Store.add('submissions', {
    studentKey: emailKey(session.email), studentName: session.name, lessonIndex: activeLesson,
    lessonTitle: LEVEL1_SCENARIOS[lang][activeLesson][0], track: lang, text: text.slice(0, 4000),
    status: 'pending', createdAt: new Date().toISOString(),
  }), tr('Misión enviada a tu profesor', 'Mission sent to your teacher'));
  btn.disabled = false;
  if (ok) { $('#missionInput').value = ''; renderStudent(); }
});

// ---------------------------------------------------------------- teacher
let reviewingId = null;

function studentStatus(s) {
  const key = s.id;
  const pending = submissions().some(x => x.studentKey === key && x.status === 'pending');
  if (pending) return ['status-orange', 'Por revisar'];
  if (pctFor(key) < 20) return ['status-red', 'Necesita apoyo'];
  return ['status-green', 'Buen progreso'];
}

function subCardForTeacher(s) {
  const reviewed = s.status === 'reviewed';
  return `<div class="sub-card">
    <h3>🎯 ${esc((s.lessonIndex + 1) + ' · ' + s.lessonTitle)}</h3>
    <p class="small">${esc(s.studentName)} · ${esc(fmtDate(s.createdAt))}</p>
    <div class="sub-text">${esc(s.text)}</div>
    ${reviewed ? `<div><span class="status status-green">${esc(s.score)}/4</span> ${esc(s.comments || '')}</div>` : ''}
    <div><button class="btn ${reviewed ? 'btn-secondary' : 'btn-primary'} btn-small" data-review="${esc(s.id)}">${reviewed ? 'Editar revisión' : 'Revisar'}</button></div>
  </div>`;
}

function renderTeacher() {
  const session = getSession();
  if (!session || session.role !== 'teacher') return;
  $('#teacherFirst').textContent = String(session.name).split(' ')[0];
  const list = students();
  const subs = submissions();
  const pending = subs.filter(s => s.status === 'pending');
  const reviewed = subs.filter(s => s.status === 'reviewed');
  const pcts = list.map(s => pctFor(s.id));
  const needSupport = list.filter(s => studentStatus(s)[1] === 'Necesita apoyo').length;

  $('#teacherStats').innerHTML = stat(list.length, 'Estudiantes') + stat(pending.length, 'Misiones por revisar') + stat(avg(pcts) + '%', 'Progreso promedio') + stat(needSupport, 'Necesitan apoyo');
  $('#teacherPendingPreview').innerHTML = pending.length
    ? pending.slice(0, 3).map(s => `<div class="lesson-row" data-review="${esc(s.id)}" role="button" tabindex="0"><div class="lesson-icon" aria-hidden="true">🎯</div><div><strong>${esc(s.studentName)}</strong><div class="small">${esc((s.lessonIndex + 1) + ' · ' + s.lessonTitle)}</div></div><span class="status status-orange">Revisar</span></div>`).join('')
    : empty('No hay misiones pendientes.');

  $('#teacherStudentsBody').innerHTML = list.length
    ? list.map(s => {
      const [cls, label] = studentStatus(s);
      const initials = String(s.name).split(' ').map(w => w[0] || '').join('').slice(0, 2).toUpperCase();
      return `<tr><td><div class="person"><div class="avatar" aria-hidden="true">${esc(initials)}</div><strong>${esc(s.name)}</strong></div></td><td>${esc(s.level)}</td><td>${pctFor(s.id)}%</td><td><span class="status ${cls}">${label}</span></td></tr>`;
    }).join('')
    : `<tr><td colspan="4">${empty('Todavía no hay estudiantes.')}</td></tr>`;

  $('#pendingSubs').innerHTML = pending.length ? pending.map(subCardForTeacher).join('') : empty('No hay misiones pendientes.');
  $('#reviewedSubs').innerHTML = reviewed.length ? reviewed.map(subCardForTeacher).join('') : empty('Todavía no hay misiones revisadas.');

  const reviewedPct = subs.length ? Math.round((reviewed.length / subs.length) * 100) : 0;
  $('#teacherProgressCard').innerHTML = `
    <p>Lecciones completadas (promedio) · ${avg(pcts)}%</p>
    <div class="progress-track"><div class="progress-fill" style="width:${avg(pcts)}%"></div></div><br>
    <p>Misiones revisadas · ${reviewedPct}% (${reviewed.length} de ${subs.length})</p>
    <div class="progress-track"><div class="progress-fill" style="width:${reviewedPct}%;background:var(--green)"></div></div>`;
}

document.addEventListener('click', e => {
  const el = e.target.closest('[data-review]');
  if (!el) return;
  const s = Store.find('submissions', el.dataset.review);
  if (!s) return;
  reviewingId = s.id;
  $('#reviewTitle').textContent = `${s.lessonIndex + 1} · ${s.lessonTitle}`;
  $('#reviewStudent').textContent = s.studentName;
  $('#reviewText').textContent = s.text;
  $('#reviewScore').value = String(s.score || 4);
  $('#reviewComments').value = s.comments || '';
  openModal('reviewModal');
});

$('#submitReviewBtn').addEventListener('click', async () => {
  if (!reviewingId) return;
  const ok = await save(Store.update('submissions', reviewingId, {
    status: 'reviewed', score: +$('#reviewScore').value, comments: $('#reviewComments').value.trim().slice(0, 2000),
    reviewedBy: getSession().name, reviewedAt: new Date().toISOString(),
  }), 'Retroalimentación enviada');
  if (ok) { closeModal('reviewModal'); reviewingId = null; }
});

// ---------------------------------------------------------------- admin
let editingStudentId = null;

function placementCell(s) {
  if (s.placementScore == null) return '<span class="small">Sin examen</span>';
  const test = s.placementTest || (s.track === 'es' ? 'Examen de inglés' : 'Examen de español');
  const res = s.placementScore + (s.placementMax ? '/' + s.placementMax : '') + (s.placementCefr ? ' · ' + s.placementCefr : '');
  const writing = s.placementWriting ? `<details class="small"><summary>Ver texto escrito</summary>${esc(s.placementWriting)}</details>` : '';
  return `<strong>${esc(res)}</strong><div class="small">${esc(test)}</div>${writing}`;
}

function renderAdmin() {
  const session = getSession();
  if (!session || session.role !== 'admin') return;
  const list = students();
  const subs = submissions();
  const certs = certificates();
  const paid = list.filter(s => s.paid).length;
  const pending = subs.filter(s => s.status === 'pending').length;

  $('#adminStats').innerHTML = stat(list.length, 'Alumnos') + stat(TEACHERS.length, 'Profesores') + stat(pending, 'Misiones por revisar') + stat(certs.length, 'Certificados');

  const q = $('#adminStudentSearch').value.trim().toLowerCase();
  const filtered = list.filter(s => !q || String(s.name).toLowerCase().includes(q) || String(s.email).toLowerCase().includes(q));
  $('#adminStudentsBody').innerHTML = filtered.length
    ? filtered.map(s => `<tr><td>${esc(s.name)}</td><td>${esc(s.email)}</td><td>${esc(fmtDate(s.createdAt))}</td><td>${esc(s.level)}</td><td>${placementCell(s)}</td><td>${esc(s.teacher)}</td><td>${pctFor(s.id)}%</td>
      <td><span class="status ${s.paid ? 'status-green' : 'status-red'}">${s.paid ? 'Pagado' : 'Pendiente'}</span></td>
      <td><div class="row-actions"><button class="btn btn-secondary btn-small" data-edit-student="${esc(s.id)}">Editar</button><button class="btn btn-secondary btn-small" data-del-student="${esc(s.id)}">Eliminar</button></div></td></tr>`).join('')
    : `<tr><td colspan="9">${empty(list.length ? 'Ningún alumno coincide con la búsqueda.' : 'Todavía no hay alumnos. Agrega uno o regístrate desde la página principal.')}</td></tr>`;

  $('#adminTeachersBody').innerHTML = TEACHERS.map(t => `<tr><td>${esc(t.name)}</td><td>${esc(t.specialty)}</td><td>${list.filter(s => s.teacher === t.name).length}</td><td><span class="status status-green">Activo</span></td></tr>`).join('');

  $('#adminLessons').innerHTML = LEVEL1_LESSONS.es.map((l, i) => {
    const lv = lessonLevel(i);
    const head = i === lv.from ? `<div class="level-head"><div class="eyebrow" style="margin:0">NIVEL ${lv.num}</div><h2>${esc(lv.es)}</h2><span class="small">Lecciones ${lv.from + 1}–${lv.to + 1}</span></div>` : '';
    return head + `<div class="lesson-row"><div class="lesson-icon" aria-hidden="true">${i + 1}</div><div><strong>Lección ${i + 1} · ${esc(l)}</strong><div class="small">Nivel ${lv.num} · ${esc(LEVEL1_LESSONS.en[i])}</div></div><button class="btn btn-secondary btn-small" data-preview-lesson="${i}">Ver</button></div>`;
  }).join('');

  $('#paymentStats').innerHTML = stat(paid, 'Pagados') + stat(list.length - paid, 'Pendientes') + stat(list.length ? Math.round((paid / list.length) * 100) + '%' : '0%', 'Al día') + stat(list.length, 'Alumnos');
  $('#paymentsBody').innerHTML = list.length
    ? list.map(s => `<tr><td>${esc(s.name)}</td><td>${esc(s.level)}</td><td><span class="status ${s.paid ? 'status-green' : 'status-red'}">${s.paid ? 'Pagado' : 'Pendiente'}</span></td>
      <td><button class="btn ${s.paid ? 'btn-secondary' : 'btn-success'} btn-small" data-toggle-paid="${esc(s.id)}">${s.paid ? 'Marcar pendiente' : 'Marcar pagado'}</button></td></tr>`).join('')
    : `<tr><td colspan="4">${empty('Todavía no hay alumnos.')}</td></tr>`;

  const sel = $('#certStudent');
  const prev = sel.value;
  sel.innerHTML = list.length ? list.map(s => `<option value="${esc(s.id)}">${esc(s.name)} · ${pctFor(s.id)}%</option>`).join('') : '<option value="">Sin alumnos</option>';
  if (list.some(s => s.id === prev)) sel.value = prev;
  $('#certBtn').disabled = !list.length;
  $('#certList').innerHTML = certs.length
    ? certs.map(c => `<div class="cert"><div style="font-size:2.4rem" aria-hidden="true">🎓</div><div class="eyebrow">VIVALINGUA</div><h2>${esc(c.name)}</h2><p>Certificado · ${esc(c.level)}</p><p class="small">${esc(fmtDate(c.issuedAt))}</p><br><button class="btn btn-secondary btn-small" data-del-cert="${esc(c.id)}">Anular</button></div>`).join('')
    : empty('Todavía no se emitió ningún certificado.');

  const pcts = list.map(s => pctFor(s.id));
  const reviewed = subs.filter(s => s.status === 'reviewed');
  const scoreAvg = reviewed.length ? (reviewed.reduce((a, s) => a + (+s.score || 0), 0) / reviewed.length).toFixed(1) : '–';
  $('#analyticsStats').innerHTML = stat(avg(pcts) + '%', 'Progreso medio') + stat(subs.length, 'Misiones enviadas') +
    stat(subs.length ? Math.round((reviewed.length / subs.length) * 100) + '%' : '0%', 'Misiones revisadas') + stat(scoreAvg, 'Puntuación media (de 4)');
}

$('#adminStudentSearch').addEventListener('input', renderAdmin);

function openStudentModal(s) {
  editingStudentId = s ? s.id : null;
  $('#studentModalTitle').textContent = s ? 'Editar alumno' : 'Registrar alumno';
  $('#newStudentTeacher').innerHTML = TEACHERS.map(t => `<option>${esc(t.name)}</option>`).join('');
  $('#newStudentName').value = s ? s.name : '';
  $('#newStudentEmail').value = s ? s.email : '';
  $('#newStudentEmail').disabled = !!s;
  $('#newStudentLevel').value = s ? s.level : 'Nivel 1';
  $('#newStudentTeacher').value = s ? s.teacher : TEACHERS[0].name;
  $('#studentModalMsg').innerHTML = '';
  openModal('studentModal');
}
$('#newStudentBtn').addEventListener('click', () => openStudentModal(null));

$('#saveStudentBtn').addEventListener('click', async () => {
  const name = $('#newStudentName').value.trim();
  const email = $('#newStudentEmail').value.trim().toLowerCase();
  const level = $('#newStudentLevel').value;
  const teacher = $('#newStudentTeacher').value;
  if (!name || !isEmail(email)) { $('#studentModalMsg').innerHTML = '<span class="status status-red">Escribe un nombre y un email válido.</span>'; return; }
  let ok;
  if (editingStudentId) {
    ok = await save(Store.update('students', editingStudentId, { name, level, teacher }), 'Alumno actualizado');
  } else {
    if (Store.find('students', emailKey(email))) { $('#studentModalMsg').innerHTML = '<span class="status status-red">Ya existe un alumno con ese email.</span>'; return; }
    STUDENT_PASSWORD = PASSWORD_PLACEHOLDER;
    ok = await save(Store.set('students', emailKey(email), { name, email, level, teacher, paid: false, createdAt: new Date().toISOString() }));
    if (ok) askConfirm(`Alumno guardado. Datos de acceso: ${email} / contraseña ${STUDENT_PASSWORD}. Anótala ahora y compártela con el alumno: no se vuelve a mostrar.`);
  }
  if (ok) closeModal('studentModal');
});

document.addEventListener('click', async e => {
  const edit = e.target.closest('[data-edit-student]');
  if (edit) { openStudentModal(Store.find('students', edit.dataset.editStudent)); return; }
  const del = e.target.closest('[data-del-student]');
  if (del) {
    const s = Store.find('students', del.dataset.delStudent);
    if (s && await askConfirm(`¿Eliminar a ${s.name}? Sus misiones y progreso se conservan.`)) await save(Store.remove('students', s.id), 'Alumno eliminado');
    return;
  }
  const paid = e.target.closest('[data-toggle-paid]');
  if (paid) {
    const s = Store.find('students', paid.dataset.togglePaid);
    if (s) await save(Store.update('students', s.id, { paid: !s.paid }), s.paid ? 'Marcado como pendiente' : 'Pago registrado');
    return;
  }
  const delCert = e.target.closest('[data-del-cert]');
  if (delCert) {
    if (await askConfirm('¿Anular este certificado?')) await save(Store.remove('certificates', delCert.dataset.delCert), 'Certificado anulado');
    return;
  }
  const prev = e.target.closest('[data-preview-lesson]');
  if (prev) {
    const i = +prev.dataset.previewLesson;
    const block = lang => { const [t, scene, s1, l1, s2, l2] = LEVEL1_SCENARIOS[lang][i]; return `<div class="scenario-card"><div class="eyebrow">${lang === 'es' ? 'PISTA INGLÉS (para hispanohablantes)' : 'PISTA ESPAÑOL (para angloparlantes)'}</div><h3>${esc(t)}</h3><div class="scene">${esc(scene)}</div><div class="dialogue-line"><strong>${esc(s1)}:</strong> ${esc(l1)}</div><div class="dialogue-line"><strong>${esc(s2)}:</strong> ${esc(l2)}</div></div>`; };
    $('#lessonModalEyebrow').textContent = `LECCIÓN ${i + 1} · NIVEL 1`;
    $('#lessonModalTitle').textContent = LEVEL1_LESSONS.es[i];
    $('#lessonModalBody').innerHTML = block('es') + block('en');
    openModal('lessonModal');
  }
});

$('#certBtn').addEventListener('click', async () => {
  const s = Store.find('students', $('#certStudent').value);
  if (!s) return;
  if (pctFor(s.id) < 100 && !await askConfirm(`${s.name} lleva ${pctFor(s.id)}% del curso. ¿Generar el certificado igualmente?`)) return;
  await save(Store.add('certificates', { studentKey: s.id, name: s.name, level: s.level, issuedAt: new Date().toISOString() }), 'Certificado generado');
});

// ---------------------------------------------------------------- render loop
function renderAll() {
  if (currentView === 'student') renderStudent();
  if (currentView === 'teacher') renderTeacher();
  if (currentView === 'admin') renderAdmin();
  if (currentView === 'login') renderLoginHelp();
}

['students', 'submissions', 'progress', 'certificates'].forEach(col => Store.subscribe(col, renderAll));

Store.ready.then(d => {
  $('#dataNote').textContent = d
    ? 'Los datos se guardan de forma segura en el servidor de VivaLingua. / Data is saved securely on the VivaLingua server.'
    : 'Los datos se guardan solo en este navegador. / Data is saved in this browser only.';
});

applyI18n();
renderQuiz();
const startSession = getSession();
showView(startSession ? startSession.role : 'home');
