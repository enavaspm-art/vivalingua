// Plaza: learn by role-playing real places with an AI partner.
// Merged from the Plaza app; ids carry a pz- prefix so they don't clash
// with the academy's own page.
(function(){
'use strict';
/* ---------- UI text: learning English → Spanish UI; any other language → English UI ---------- */
const TXT = {
 es:{
  'aria.home':'Plaza, ir al inicio','aria.back':'Volver al mapa','aria.mic':'Hablar con el micrófono',
  'nav.sit':'Situaciones','nav.how':'Cómo funciona','nav.fam':'Para familias','nav.prog':'Mi progreso','nav.start':'Empieza gratis',
  'hero.title':'Aprende el idioma de los lugares que visitas cada día.',
  'hero.lead':'Nada de "Lección 14". Aquí dominas el restaurante, la cita médica o la entrevista de trabajo, conversando con un compañero de IA que actúa la escena contigo.',
  'lv.label':'Tu nivel','lv.a':'Principiante (A1–A2)','lv.b':'Intermedio (B1–B2)','lv.c':'Avanzado (C1–C2)',
  'st.mastered':'Dominada','st.progress':'En curso','st.new':'Nueva',
  'how.title':'Cada situación, en tres pasos',
  'how.s1t':'Elige un lugar','how.s1p':'Toca un lugar del mapa: aeropuerto, médico, banco, trabajo… Cada uno es una situación real.',
  'how.s2t':'Toma tu papel','how.s2p':'Elige quién eres en la escena. La IA actúa el otro papel, te responde y te corrige con calma.',
  'how.s3t':'Cumple la misión','how.s3p':'Completa los objetivos de la escena y descubre costumbres del país. Así la situación queda dominada.',
  'mir.title':'Dos idiomas, una misma escena.',
  'mir.lead':'Con el modo espejo, cada respuesta aparece también traducida. Padres e hijos, o compañeros de clase, pueden practicar idiomas distintos con la misma conversación.',
  'mir.on':'Modo espejo: activado','mir.off':'Modo espejo: desactivado','mir.example':'Ejemplo: Restaurante','mir.waiter':'Mesero','mir.customer':'Cliente',
  'prog.title':'Tu progreso: lo que ya puedes hacer','prog.reset':'Borrar mi progreso en este idioma',
  'prog.summary':(m,n,l)=>'Has dominado '+m+' de '+n+' situaciones en '+l+'.',
  'prog.next':(p)=>'Siguiente: '+p,'prog.all':'¡Todo dominado! Repasa el restaurante',
  'prog.confirm':(l)=>'¿Borrar tu progreso en '+l+'? No se puede deshacer.',
  'hero.start':(p)=>'Empieza con: '+p,'hero.review':'Repasa el restaurante',
  'card.meta':(st,pct,l,c)=>st+' · '+pct+'% · '+l+' en '+c,'card.enter':'Entrar a la escena','card.continue':'Seguir practicando',
  'footer':'Plaza · prototipo funcional',
  'sc.setting':'La escena','sc.role':'Tu papel','sc.mirror':'Modo espejo','sc.on':'Activado','sc.off':'Desactivado','sc.restart':'Reiniciar escena',
  'sc.mission':'Tu misión','sc.mastered':'¡Situación dominada!','sc.answer':'Tu respuesta','sc.send':'Enviar','sc.hint':'Enter para enviar · Shift + Enter para nueva línea',
  'sc.meta':(l,c,lv)=>l+' · '+c+' · Nivel '+lv,'sc.chooseRole':'Elige tu papel para ver la misión.','sc.empty':'Elige tu papel y la IA empezará la conversación.',
  'sc.play':(r)=>'Ser '+r,'sc.typing':(n)=>n+' está escribiendo…','sc.you':'Tú','sc.ai':'IA','sc.listen':'Escuchar','sc.done':' (logrado)',
  'sc.fix':'Sugerencia: ','sc.culture':'Nota cultural: ','sc.ph':(l)=>'Escribe tu respuesta en '+l+'…',
  'sc.complete':(p,r)=>'¡Misión cumplida! Dominaste: '+p+' ('+r+'). Puedes seguir conversando o volver al mapa.',
  'err.na':'La IA no está disponible en esta vista. Abre la página publicada en Claude, con tu sesión iniciada, para conversar.',
  'err.grant':'Para conversar necesitas permitir que la página use Claude. Vuelve a cargar la página e intenta de nuevo.',
  'err.rate':'Demasiados mensajes seguidos. Espera un momento y vuelve a enviar.',
  'err.send':'No llegó la respuesta. Vuelve a enviar tu mensaje.','err.start':'No se pudo iniciar la escena. Toca "Reiniciar escena".',
  'err.mic':'No se pudo usar el micrófono aquí. Escribe tu respuesta.'
 },
 en:{
  'aria.home':'Plaza, go to home','aria.back':'Back to the map','aria.mic':'Speak with the microphone',
  'nav.sit':'Situations','nav.how':'How it works','nav.fam':'For families','nav.prog':'My progress','nav.start':'Start free',
  'hero.title':'Learn the language of the places you visit every day.',
  'hero.lead':'No more "Lesson 14." Here you master the restaurant, the doctor\'s visit or the job interview by talking with an AI partner who acts out the scene with you.',
  'lv.label':'Your level','lv.a':'Beginner (A1–A2)','lv.b':'Intermediate (B1–B2)','lv.c':'Advanced (C1–C2)',
  'st.mastered':'Mastered','st.progress':'In progress','st.new':'New',
  'how.title':'Every situation, in three steps',
  'how.s1t':'Pick a place','how.s1p':'Tap a place on the map: airport, doctor, bank, work… Each one is a real-life situation.',
  'how.s2t':'Take your role','how.s2p':'Choose who you are in the scene. The AI plays the other role, answers you and corrects you calmly.',
  'how.s3t':'Complete the mission','how.s3p':'Reach the scene\'s goals and discover the country\'s customs. That\'s how you master a situation.',
  'mir.title':'Two languages, one scene.',
  'mir.lead':'With mirror mode, every reply also appears translated. Parents and children, or classmates, can practice different languages with the same conversation.',
  'mir.on':'Mirror mode: on','mir.off':'Mirror mode: off','mir.example':'Example: Restaurant','mir.waiter':'Waiter','mir.customer':'Customer',
  'prog.title':'Your progress: what you can already do','prog.reset':'Clear my progress in this language',
  'prog.summary':(m,n,l)=>'You have mastered '+m+' of '+n+' situations in '+l+'.',
  'prog.next':(p)=>'Next: '+p,'prog.all':'All mastered! Review the restaurant',
  'prog.confirm':(l)=>'Clear your progress in '+l+'? This can\'t be undone.',
  'hero.start':(p)=>'Start with: '+p,'hero.review':'Review the restaurant',
  'card.meta':(st,pct,l,c)=>st+' · '+pct+'% · '+l+' in '+c,'card.enter':'Enter the scene','card.continue':'Keep practicing',
  'footer':'Plaza · working prototype',
  'sc.setting':'The scene','sc.role':'Your role','sc.mirror':'Mirror mode','sc.on':'On','sc.off':'Off','sc.restart':'Restart scene',
  'sc.mission':'Your mission','sc.mastered':'Situation mastered!','sc.answer':'Your answer','sc.send':'Send','sc.hint':'Enter to send · Shift + Enter for a new line',
  'sc.meta':(l,c,lv)=>l+' · '+c+' · Level '+lv,'sc.chooseRole':'Choose your role to see the mission.','sc.empty':'Choose your role and the AI will start the conversation.',
  'sc.play':(r)=>'Play the '+r,'sc.typing':(n)=>n+' is typing…','sc.you':'You','sc.ai':'AI','sc.listen':'Listen','sc.done':' (done)',
  'sc.fix':'Tip: ','sc.culture':'Cultural note: ','sc.ph':(l)=>'Write your answer in '+l+'…',
  'sc.complete':(p,r)=>'Mission complete! You mastered: '+p+' ('+r+'). Keep talking or go back to the map.',
  'err.na':'The AI isn\'t available in this view. Open the published page in Claude, signed in, to start talking.',
  'err.grant':'To talk, allow this page to use Claude. Reload the page and try again.',
  'err.rate':'Too many messages in a row. Wait a moment and send again.',
  'err.send':'The reply didn\'t arrive. Send your message again.','err.start':'The scene couldn\'t start. Tap "Restart scene".',
  'err.mic':'The microphone isn\'t available here. Type your answer instead.'
 }
};
/* ---------- data ---------- */
const LANGS = {
  en:{self:'English', name:{es:'inglés',en:'English'}, target:'English', country:'the United States', countryT:{es:'EE. UU.',en:'the U.S.'}, speech:'en-US'},
  es:{self:'Español', name:{es:'español',en:'Spanish'}, target:'Spanish', country:'Mexico', countryT:{es:'México',en:'Mexico'}, speech:'es-MX'},
  fr:{self:'Français', name:{es:'francés',en:'French'}, target:'French', country:'France', countryT:{es:'Francia',en:'France'}, speech:'fr-FR'},
  pt:{self:'Português', name:{es:'portugués',en:'Portuguese'}, target:'Portuguese', country:'Brazil', countryT:{es:'Brasil',en:'Brazil'}, speech:'pt-BR'},
  de:{self:'Deutsch', name:{es:'alemán',en:'German'}, target:'German', country:'Germany', countryT:{es:'Alemania',en:'Germany'}, speech:'de-DE'},
  it:{self:'Italiano', name:{es:'italiano',en:'Italian'}, target:'Italian', country:'Italy', countryT:{es:'Italia',en:'Italy'}, speech:'it-IT'}
};
const g = (id, es, en) => ({id, label:{es, en}});
const R = (id, es, en, ai, goals) => ({id, name:{es, en}, ai, goals});
const PLACES = [
 {id:'aeropuerto', name:{es:'Aeropuerto',en:'Airport'}, x:'5%', y:'10%',
  desc:{es:'Facturar, entregar documentos y encontrar tu puerta.',en:'Check in, hand over documents and find your gate.'},
  setting:'the check-in counter of an airline at the airport',
  settingT:{es:'El mostrador de facturación de una aerolínea en el aeropuerto.',en:'An airline check-in counter at the airport.'},
  roles:[R('a','Pasajero','Passenger','airline check-in agent',[g('greet','Saludar al agente','Greet the agent'),g('docs','Entregar tu pasaporte o reserva','Hand over your passport or booking'),g('bag','Facturar o preguntar por tu maleta','Check or ask about your bag'),g('gate','Preguntar por la puerta o la hora de embarque','Ask about the gate or boarding time')]),
         R('b','Agente','Agent','traveler checking in for a flight',[g('greet','Saludar y pedir el pasaporte','Greet and ask for the passport'),g('dest','Preguntar el destino','Ask for the destination'),g('bag','Preguntar por el equipaje','Ask about luggage'),g('gate','Indicar la puerta y la hora de embarque','Give the gate and boarding time')])]},
 {id:'hotel', name:{es:'Hotel',en:'Hotel'}, x:'35%', y:'20%',
  desc:{es:'Registrarte, pedir lo que necesitas y resolver un problema.',en:'Check in, ask for what you need and solve a problem.'},
  setting:'the front desk of a hotel', settingT:{es:'La recepción de un hotel a la hora del check-in.',en:'A hotel front desk at check-in time.'},
  roles:[R('a','Huésped','Guest','hotel receptionist',[g('name','Saludar y dar tu nombre','Greet and give your name'),g('nights','Confirmar las noches de tu reserva','Confirm the nights of your booking'),g('ask','Pedir algo (toallas, wifi, desayuno)','Ask for something (towels, wifi, breakfast)'),g('problem','Reportar un problema en la habitación','Report a problem in the room')]),
         R('b','Recepcionista','Receptionist','hotel guest arriving to check in',[g('welcome','Dar la bienvenida','Welcome the guest'),g('id','Pedir nombre e identificación','Ask for name and ID'),g('breakfast','Explicar el horario del desayuno','Explain breakfast hours'),g('solve','Resolver un problema del huésped','Solve a guest\'s problem')])]},
 {id:'restaurante', name:{es:'Restaurante',en:'Restaurant'}, x:'65%', y:'12%',
  desc:{es:'Pedir, preguntar por ingredientes y pagar la cuenta.',en:'Order, ask about ingredients and pay the check.'},
  setting:'a casual café', settingT:{es:'Una cafetería sencilla a la hora del almuerzo.',en:'A casual café at lunchtime.'},
  roles:[R('a','Cliente','Customer','waiter',[g('greet','Saludar','Greet'),g('drink','Pedir una bebida','Order a drink'),g('food','Pedir un plato','Order a dish'),g('ask','Preguntar por un ingrediente','Ask about an ingredient'),g('bill','Pedir la cuenta','Ask for the check')]),
         R('b','Mesero','Waiter','customer at the café',[g('welcome','Dar la bienvenida','Welcome the customer'),g('drink','Tomar la orden de bebida','Take the drink order'),g('recommend','Recomendar un plato','Recommend a dish'),g('bill','Llevar la cuenta','Bring the check')])]},
 {id:'banco', name:{es:'Banco',en:'Bank'}, x:'33%', y:'47%',
  desc:{es:'Abrir una cuenta y explicar un cargo que no reconoces.',en:'Open an account and explain a charge you don\'t recognize.'},
  setting:'a bank branch', settingT:{es:'La ventanilla de atención al cliente de un banco.',en:'The customer service desk at a bank.'},
  roles:[R('a','Cliente','Customer','bank employee',[g('greet','Saludar','Greet'),g('open','Decir que quieres abrir una cuenta','Say you want to open an account'),g('docs','Preguntar qué documentos necesitas','Ask which documents you need'),g('charge','Explicar un cargo que no reconoces','Explain a charge you don\'t recognize')]),
         R('b','Empleado','Employee','bank customer',[g('greet','Saludar','Greet'),g('help','Preguntar en qué puedes ayudar','Ask how you can help'),g('id','Pedir identificación','Ask for ID'),g('next','Explicar los siguientes pasos','Explain the next steps')])]},
 {id:'mercado', name:{es:'Mercado',en:'Market'}, x:'67%', y:'52%',
  desc:{es:'Preguntar precios y cantidades, y regatear con respeto.',en:'Ask prices and quantities, and bargain politely.'},
  setting:'a fruit and vegetable stand at a local market', settingT:{es:'Un puesto de frutas y verduras en un mercado local.',en:'A fruit and vegetable stand at a local market.'},
  roles:[R('a','Comprador','Shopper','market vendor',[g('greet','Saludar','Greet'),g('price','Preguntar un precio','Ask a price'),g('qty','Pedir una cantidad (un kilo, una docena)','Ask for a quantity (a kilo, a dozen)'),g('deal','Pedir un descuento con respeto','Politely ask for a discount'),g('pay','Pagar y despedirte','Pay and say goodbye')]),
         R('b','Vendedor','Vendor','shopper at the market',[g('offer','Saludar y ofrecer productos','Greet and offer products'),g('price','Decir un precio','Say a price'),g('qty','Ofrecer una cantidad','Offer a quantity'),g('change','Cobrar y dar el cambio','Charge and give change')])]},
 {id:'medico', name:{es:'Médico',en:'Doctor'}, x:'3%', y:'50%',
  desc:{es:'Describir síntomas y entender las indicaciones.',en:'Describe symptoms and understand instructions.'},
  setting:'a doctor\'s office at a clinic', settingT:{es:'El consultorio de una clínica durante una consulta.',en:'A doctor\'s office at a clinic during a visit.'},
  roles:[R('a','Paciente','Patient','doctor',[g('greet','Saludar','Greet'),g('symptoms','Describir tus síntomas','Describe your symptoms'),g('since','Decir desde cuándo te sientes así','Say how long you\'ve felt this way'),g('treatment','Preguntar cómo seguir el tratamiento','Ask how to follow the treatment')]),
         R('b','Doctor','Doctor','patient with a cold',[g('greet','Saludar','Greet'),g('what','Preguntar qué le pasa','Ask what\'s wrong'),g('since','Preguntar desde cuándo','Ask since when'),g('advice','Dar una indicación clara','Give clear advice')])]},
 {id:'escuela', name:{es:'Escuela',en:'School'}, x:'33%', y:'79%',
  desc:{es:'Reunión con el maestro sobre el avance de tu hijo.',en:'A meeting with the teacher about your child\'s progress.'},
  setting:'a parent-teacher meeting at an elementary school', settingT:{es:'Una reunión de padres y maestros en una escuela primaria.',en:'A parent-teacher meeting at an elementary school.'},
  roles:[R('a','Padre o madre','Parent','elementary school teacher',[g('intro','Presentarte','Introduce yourself'),g('how','Preguntar cómo va tu hijo','Ask how your child is doing'),g('home','Preguntar cómo ayudar en casa','Ask how to help at home'),g('follow','Acordar un próximo contacto','Agree on a next check-in')]),
         R('b','Maestro','Teacher','parent of a student',[g('greet','Saludar','Greet'),g('praise','Compartir un logro del estudiante','Share a student achievement'),g('improve','Mencionar algo por mejorar','Mention something to improve'),g('home','Sugerir cómo ayudar en casa','Suggest how to help at home')])]},
 {id:'trabajo', name:{es:'Trabajo',en:'Work'}, x:'64%', y:'82%',
  desc:{es:'Una entrevista de trabajo, de principio a fin.',en:'A job interview, from start to finish.'},
  setting:'a job interview at an office', settingT:{es:'Una entrevista de trabajo en una oficina.',en:'A job interview at an office.'},
  roles:[R('a','Candidato','Candidate','hiring manager interviewing a candidate',[g('intro','Saludar y presentarte','Greet and introduce yourself'),g('exp','Hablar de tu experiencia','Talk about your experience'),g('why','Explicar por qué quieres el puesto','Explain why you want the job'),g('question','Hacer una pregunta sobre el trabajo','Ask a question about the job')]),
         R('b','Entrevistador','Interviewer','job candidate',[g('welcome','Dar la bienvenida','Welcome the candidate'),g('exp','Preguntar por la experiencia','Ask about experience'),g('strength','Preguntar por sus fortalezas','Ask about strengths'),g('next','Explicar los siguientes pasos','Explain the next steps')])]}
];
const LEVELS = {'A1-A2':'A1-A2 (beginner: short, simple sentences, very common words)','B1-B2':'B1-B2 (intermediate: natural but clear)','C1-C2':'C1-C2 (advanced: fully natural, idiomatic)'};

/* ---------- state & storage ---------- */
const LS_KEY = 'plaza-v1';
let S = { lang:'en', level:'B1-B2', mirror:true, progress:{} };
let selPlace = 'restaurante';
let dbRef = null;
const ui = () => (S.lang === 'en' ? 'es' : 'en');
const supportLang = () => (ui() === 'es' ? 'Spanish' : 'English');
function t(key, ...a){ const v = TXT[ui()][key]; return typeof v === 'function' ? v(...a) : (v == null ? key : v); }
const L = (obj) => obj[ui()];

function applyI18n(){
  const root = $('view-plaza');
  root.setAttribute('lang', ui());
  root.querySelectorAll('[data-pz]').forEach((n) => { n.textContent = t(n.getAttribute('data-pz')); });
  root.querySelectorAll('[data-pz-aria]').forEach((n) => { n.setAttribute('aria-label', t(n.getAttribute('data-pz-aria'))); });
}

function loadLocal(){
  let hadLocal = false;
  try { const raw = localStorage.getItem(LS_KEY); if (raw) { hadLocal = true; const d = JSON.parse(raw); if (d && typeof d === 'object') S = Object.assign(S, d); } } catch(_){}
  if (!LANGS[S.lang]) S.lang = 'en';
  if (!hadLocal) { let site = 'es'; try { site = localStorage.getItem('navasSiteLang') || 'es'; } catch(_){} S.lang = site === 'es' ? 'en' : 'es'; }
}
let saveTimer = null;
function save(){
  try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch(_){}
  notify();
  if (dbRef) { clearTimeout(saveTimer); saveTimer = setTimeout(() => { dbRef.set({ state: JSON.stringify(S), updatedAt: new Date().toISOString() }).catch(() => {}); }, 800); }
}
async function connectDb(){
  try {
    if (!window.claude || !window.claude.use) return;
    const [db, user] = await Promise.all([window.claude.use('db'), window.claude.use('user')]);
    if (!db || !user) return;
    const id = await user.id();
    if (!id) return;
    dbRef = db.doc('data/users/' + id + '/plaza');
    const snap = await dbRef.get();
    if (snap.exists) {
      try { const parsed = JSON.parse(snap.data().state); if (parsed && typeof parsed === 'object') { S = Object.assign(S, parsed); if (!LANGS[S.lang]) S.lang = 'en'; if ($('pz-scene').hidden) renderHome(); notify(); } } catch(_){}
    } else { save(); }
  } catch(_) { dbRef = null; }
}

function prog(lang, place){ return ((S.progress[lang] || {})[place]) || {}; }
function doneFor(lang, place, role){ return new Set((prog(lang, place)[role]) || []); }
function placeStats(lang, p){
  let best = 0, mastered = false, any = false;
  p.roles.forEach((r) => {
    const d = doneFor(lang, p.id, r.id).size;
    if (d > 0) any = true;
    if (d >= r.goals.length) mastered = true;
    best = Math.max(best, d / r.goals.length);
  });
  const key = mastered ? 'mastered' : (any ? 'progress' : 'new');
  return { key, status: t('st.' + key), pct: Math.round((mastered ? 1 : best) * 100), cls: mastered ? 'dominada' : (any ? 'encurso' : 'nueva') };
}

/* ---------- helpers ---------- */
const $ = (id) => document.getElementById(id);
function el(tag, attrs, ...kids){
  const n = document.createElement(tag);
  if (attrs) for (const k in attrs) { if (k === 'class') n.className = attrs[k]; else if (k === 'text') n.textContent = attrs[k]; else if (k.startsWith('on')) n.addEventListener(k.slice(2), attrs[k]); else n.setAttribute(k, attrs[k]); }
  kids.forEach((c) => { if (c != null) n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
  return n;
}

/* ---------- home ---------- */
function renderHome(){
  applyI18n();
  const lp = $('pz-langPills'); lp.textContent = '';
  Object.keys(LANGS).forEach((k) => {
    lp.appendChild(el('button', {type:'button', class:'pill', lang:k, 'aria-pressed': String(S.lang === k), text: LANGS[k].self, onclick: () => { S.lang = k; save(); renderHome(); }}));
  });
  $('pz-levelSel').value = S.level;
  const map = $('pz-map');
  map.setAttribute('aria-label', t('nav.sit'));
  map.querySelectorAll('.pin').forEach((n) => n.remove());
  PLACES.forEach((p) => {
    const st = placeStats(S.lang, p);
    map.appendChild(el('button', {type:'button', class:'pin', 'aria-pressed': String(p.id === selPlace), style:'left:' + p.x + ';top:' + p.y, 'aria-label': L(p.name) + ', ' + st.status, onclick: () => { selPlace = p.id; renderHome(); }},
      el('span', {class:'dot ' + st.cls}), L(p.name)));
  });
  const p = PLACES.find((x) => x.id === selPlace);
  const st = placeStats(S.lang, p);
  const lg = LANGS[S.lang];
  const card = $('pz-placeCard'); card.textContent = '';
  card.appendChild(el('div', {class:'stack', style:'gap:4px'},
    el('span', {class:'meta', text: t('card.meta', st.status, st.pct, cap(L(lg.name)), L(lg.countryT))}),
    el('h2', {text: L(p.name)}),
    el('p', {text: L(p.desc)})));
  card.appendChild(el('button', {type:'button', class:'btn gold', text: st.key === 'new' ? t('card.enter') : t('card.continue'), onclick: () => openScene(p.id)}));
  const grid = $('pz-progGrid'); grid.textContent = '';
  let mastered = 0, next = null;
  PLACES.forEach((pl) => {
    const s = placeStats(S.lang, pl);
    if (s.key === 'mastered') mastered++; else if (!next) next = pl;
    const fill = el('div'); fill.style.width = s.pct + '%';
    grid.appendChild(el('button', {type:'button', class:'prog-item', onclick: () => openScene(pl.id), 'aria-label': L(pl.name) + ': ' + s.status + ', ' + s.pct + '%'},
      el('span', {style:'font-size:18px;font-weight:600', text: L(pl.name)}),
      el('div', {class:'bar'}, fill),
      el('span', {class:'note', text: s.status + (s.key === 'progress' ? ' · ' + s.pct + '%' : '')})));
  });
  $('pz-progSummary').textContent = t('prog.summary', mastered, PLACES.length, L(lg.name));
  const nb = $('pz-nextBtn');
  nb.textContent = next ? t('prog.next', L(next.name)) : t('prog.all');
  nb.onclick = () => openScene(next ? next.id : 'restaurante');
  const sn = $('pz-startNext');
  sn.textContent = next ? t('hero.start', L(next.name)) : t('hero.review');
  sn.onclick = () => openScene(next ? next.id : 'restaurante');
  renderMirrorDemo();
}
function cap(s){ return s.charAt(0).toUpperCase() + s.slice(1); }
let demoMirror = true;
function renderMirrorDemo(){
  const btn = $('pz-mirrorDemoBtn');
  btn.setAttribute('aria-pressed', String(demoMirror));
  btn.textContent = demoMirror ? t('mir.on') : t('mir.off');
  const d = $('pz-mirrorDemo'); d.textContent = '';
  d.appendChild(el('span', {style:'font-size:13px;font-weight:600;color:var(--muted)', text: t('mir.example')}));
  const rows = [
    ['w','Hi! Are you ready to order?','¡Hola! ¿Ya sabe qué va a pedir?'],
    ['c','Yes, could I get the soup, please?','Sí, ¿me trae la sopa, por favor?'],
    ['w','Sure. Anything to drink?','Claro. ¿Algo de tomar?']
  ];
  // Show the language being learned first, the page's language second
  const firstEs = ui() === 'en';
  rows.forEach((r) => {
    const bg = r[0] === 'w' ? 'var(--waiter)' : 'var(--me)';
    const who = r[0] === 'w' ? t('mir.waiter') : t('mir.customer');
    const a = firstEs ? ['ES', r[2]] : ['EN', r[1]];
    const b = firstEs ? ['EN', r[1]] : ['ES', r[2]];
    const row = el('div', {class:'demo-row' + (demoMirror ? '' : ' one')});
    row.appendChild(el('div', {class:'bubble', style:'background:' + bg}, el('small', {text: who + ' · ' + a[0]}), a[1]));
    if (demoMirror) row.appendChild(el('div', {class:'bubble', style:'background:' + bg}, el('small', {text: who + ' · ' + b[0]}), b[1]));
    d.appendChild(row);
  });
}
$('pz-mirrorDemoBtn').addEventListener('click', () => { demoMirror = !demoMirror; renderMirrorDemo(); });
$('pz-levelSel').addEventListener('change', (e) => { S.level = e.target.value; save(); });
$('pz-resetProg').addEventListener('click', () => {
  window.askConfirm(t('prog.confirm', L(LANGS[S.lang].name))).then((ok) => { if (ok) { delete S.progress[S.lang]; save(); renderHome(); } });
});


/* ---------- scene ---------- */
let SC = null;
let samplePromise = (window.claude && window.claude.use) ? window.claude.use('sample') : Promise.resolve(null);
let sample;
samplePromise.then((s) => { sample = s; });

function openScene(placeId){
  const p = PLACES.find((x) => x.id === placeId);
  selPlace = placeId;
  SC = { place:p, role:null, history:[], busy:false, controller:null };
  applyI18n();
  $('pz-home').hidden = true; $('pz-scene').hidden = false;
  window.scrollTo(0,0);
  const lg = LANGS[S.lang];
  $('pz-sceneMeta').textContent = t('sc.meta', cap(L(lg.name)), L(lg.countryT), S.level);
  $('pz-sceneTitle').textContent = L(p.name);
  $('pz-sceneSetting').textContent = L(p.settingT) + ' ' + L(p.desc);
  $('pz-input').placeholder = t('sc.ph', L(lg.name));
  $('pz-input').setAttribute('lang', S.lang);
  renderMirrorBtn();
  renderRoles(); renderGoals(); showEmpty();
  setComposer(false);
  $('pz-err').textContent = '';
}
function renderMirrorBtn(){
  $('pz-mirrorBtn').setAttribute('aria-pressed', String(S.mirror));
  $('pz-mirrorBtn').textContent = S.mirror ? t('sc.on') : t('sc.off');
  $('pz-log').classList.toggle('hide-tr', !S.mirror);
}
function closeScene(){
  if (SC && SC.controller) SC.controller.abort();
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  SC = null; $('pz-scene').hidden = true; $('pz-home').hidden = false; renderHome();
}
$('pz-backBtn').addEventListener('click', () => { closeScene(); document.getElementById('pz-situaciones').scrollIntoView(); });

function renderRoles(){
  const box = $('pz-roles'); box.textContent = '';
  SC.place.roles.forEach((r) => {
    box.appendChild(el('button', {type:'button', class:'pill', 'aria-pressed': String(!!SC.role && SC.role.id === r.id), text: L(r.name), onclick: () => startRole(r)}));
  });
}
function renderGoals(){
  const ul = $('pz-goals'); ul.textContent = '';
  if (!SC.role) { ul.appendChild(el('li', {text: t('sc.chooseRole')})); $('pz-banner').hidden = true; return; }
  const done = doneFor(S.lang, SC.place.id, SC.role.id);
  SC.role.goals.forEach((gl) => {
    const ok = done.has(gl.id);
    ul.appendChild(el('li', {class: ok ? 'done' : ''}, el('span', {class:'check', 'aria-hidden':'true', text: ok ? '✓' : ''}), el('span', {text: L(gl.label) + (ok ? t('sc.done') : '')})));
  });
  $('pz-banner').hidden = done.size < SC.role.goals.length;
}
function showEmpty(){
  const log = $('pz-log'); log.textContent = '';
  log.appendChild(el('div', {class:'pz-empty'},
    el('p', {style:'margin:0;font-size:17px', text: t('sc.empty')}),
    el('div', {class:'pz-row', style:'justify-content:center'}, ...SC.place.roles.map((r) => el('button', {type:'button', class:'btn primary', text: t('sc.play', ui() === 'es' ? L(r.name).toLowerCase() : L(r.name).toLowerCase()), onclick: () => startRole(r)})))));
}
function setComposer(on){ $('pz-input').disabled = !on; $('pz-sendBtn').disabled = !on; $('pz-mic').disabled = !on; }
function startRole(r){
  if (SC.controller) SC.controller.abort();
  SC.role = r; SC.history = []; SC.busy = false;
  renderRoles(); renderGoals();
  $('pz-log').textContent = ''; $('pz-err').textContent = '';
  turn(null);
}
$('pz-restartBtn').addEventListener('click', () => { if (SC && SC.role) startRole(SC.role); else if (SC) showEmpty(); });
$('pz-mirrorBtn').addEventListener('click', () => { S.mirror = !S.mirror; save(); renderMirrorBtn(); });

function scrollLog(){ const l = $('pz-log'); l.scrollTop = l.scrollHeight; }
function speak(text){
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text); u.lang = LANGS[S.lang].speech; u.rate = S.level === 'A1-A2' ? 0.85 : 0.95;
  window.speechSynthesis.speak(u);
}
function aiRole(){ return SC.place.roles.find((r) => r.id !== SC.role.id); }
function addAi(text, tr){
  const m = el('div', {class:'msg ai'}, el('span', {class:'who', text: L(aiRole().name) + ' (' + t('sc.ai') + ')'}), el('span', {lang:S.lang, text}));
  if (tr) m.appendChild(el('span', {class:'tr', text: tr}));
  $('pz-log').appendChild(m);
  if ('speechSynthesis' in window) $('pz-log').appendChild(el('button', {type:'button', class:'speak', text: t('sc.listen'), onclick: () => speak(text)}));
  scrollLog();
}
function addMe(text){ $('pz-log').appendChild(el('div', {class:'msg me'}, el('span', {class:'who', text: t('sc.you') + ' · ' + L(SC.role.name)}), el('span', {lang:S.lang, text}))); scrollLog(); }

function buildPrompt(){
  const lg = LANGS[S.lang], p = SC.place, r = SC.role, sup = supportLang();
  const convo = SC.history.length ? SC.history.map((h) => (h.who === 'ai' ? 'YOU: ' : 'STUDENT: ') + h.text).join('\n') : '(no messages yet — you speak first)';
  const goals = r.goals.map((gl) => '- ' + gl.id + ': the student will ' + gl.label.en.toLowerCase()).join('\n');
  return 'You are role-playing in a language-learning app. Scene: ' + p.setting + ' in ' + lg.country + '. You play the ' + r.ai + '. The student plays the ' + r.name.en.toLowerCase() + '.\n' +
  'The student is learning ' + lg.target + ' at level ' + LEVELS[S.level] + '. Their support language is ' + sup + '.\n\n' +
  'Rules:\n' +
  '- Stay in character and keep the scene realistic for ' + lg.country + '. Write "reply" ONLY in ' + lg.target + ', 1-2 short sentences matched to the level. Be warm and patient.\n' +
  '- Steer the conversation so the student gets chances to complete the mission goals below, without telling them the goals.\n' +
  '- If the student writes in ' + sup + ' or seems stuck, stay in character but give a simpler line or a gentle hint in ' + lg.target + '.\n' +
  '- "correction": look ONLY at the student\'s LAST message. If it has a grammar, vocabulary or unnatural-phrasing mistake in ' + lg.target + ', write one short, kind sentence in ' + sup + ' that includes the better phrase in ' + lg.target + '. Otherwise "". If there is no student message yet, "".\n' +
  '- "goals": ids of the mission goals the STUDENT has clearly accomplished at any point in the conversation (not things you did). Mission goals:\n' + goals + '\n' +
  '- "culture": only occasionally (about one turn in three), one short sentence in ' + sup + ' about a real custom in ' + lg.country + ' relevant to this scene; otherwise "".\n' +
  '- "translation": your reply translated into ' + sup + '.\n\n' +
  'Conversation so far:\n' + convo + '\n\n' +
  'Respond with ONLY this JSON object, no markdown:\n{"reply":"","translation":"","correction":"","goals":[],"culture":""}';
}

async function turn(studentText){
  if (!SC || !SC.role || SC.busy) return;
  if (sample === undefined) sample = await samplePromise;
  if (!sample) { $('pz-err').textContent = t('err.na'); setComposer(false); return; }
  const scRef = SC;
  SC.busy = true; setComposer(false); $('pz-err').textContent = '';
  if (studentText) { addMe(studentText); SC.history.push({who:'me', text:studentText}); $('pz-input').value = ''; }
  const typing = el('div', {class:'typing', text: t('sc.typing', L(aiRole().name))});
  $('pz-log').appendChild(typing); scrollLog();
  const controller = new AbortController(); SC.controller = controller;
  try {
    const r = await sample.json(buildPrompt(), { modelTier:'default', cache:false, signal: controller.signal });
    if (SC !== scRef) return;
    typing.remove();
    if (studentText && r.correction) $('pz-log').appendChild(el('div', {class:'fix', text: t('sc.fix') + r.correction}));
    const reply = String(r.reply || '').trim() || '…';
    SC.history.push({who:'ai', text:reply});
    addAi(reply, String(r.translation || ''));
    if (r.culture) $('pz-log').appendChild(el('div', {class:'culture', text: t('sc.culture') + r.culture}));
    scrollLog();
    if (studentText && Array.isArray(r.goals)) {
      const valid = new Set(SC.role.goals.map((x) => x.id));
      const done = doneFor(S.lang, SC.place.id, SC.role.id);
      const before = done.size;
      r.goals.forEach((id) => { if (valid.has(id)) done.add(id); });
      if (done.size !== before) {
        S.progress[S.lang] = S.progress[S.lang] || {};
        S.progress[S.lang][SC.place.id] = S.progress[S.lang][SC.place.id] || {};
        S.progress[S.lang][SC.place.id][SC.role.id] = Array.from(done);
        save(); renderGoals();
        if (done.size >= SC.role.goals.length && before < SC.role.goals.length) {
          $('pz-log').appendChild(el('div', {class:'pz-banner', style:'align-self:stretch', text: t('sc.complete', L(SC.place.name), L(SC.role.name))}));
          scrollLog();
        }
      }
    }
  } catch (e) {
    if (SC !== scRef) return;
    typing.remove();
    const code = e && e.code;
    if (code === 'cancelled') return;
    if (studentText) { SC.history.pop(); $('pz-input').value = studentText; }
    $('pz-err').textContent = code === 'not_granted' ? t('err.grant') : code === 'rate_limited' ? t('err.rate') : studentText ? t('err.send') : t('err.start');
  } finally {
    if (SC === scRef) { SC.busy = false; SC.controller = null; setComposer(true); $('pz-input').focus(); }
  }
}
$('pz-form').addEventListener('submit', (e) => { e.preventDefault(); const v = $('pz-input').value.trim(); if (v) turn(v); });
$('pz-input').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); const v = $('pz-input').value.trim(); if (v) turn(v); } });

/* voice input */
const SRc = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SRc) {
  const mic = $('pz-mic'); mic.hidden = false; let rec = null;
  mic.addEventListener('click', () => {
    if (rec) { rec.stop(); return; }
    try {
      rec = new SRc(); rec.lang = LANGS[S.lang].speech; rec.interimResults = true;
      mic.setAttribute('aria-pressed','true');
      rec.onresult = (ev) => { $('pz-input').value = Array.from(ev.results).map((x) => x[0].transcript).join(' '); };
      rec.onerror = () => { $('pz-err').textContent = t('err.mic'); };
      rec.onend = () => { mic.setAttribute('aria-pressed','false'); rec = null; const v = $('pz-input').value.trim(); if (v && SC && !SC.busy) turn(v); };
      rec.start();
    } catch(_) { mic.hidden = true; rec = null; }
  });
}

/* bridge to the academy */
function stats(){
  let mastered = 0, next = null;
  PLACES.forEach((pl) => { if (placeStats(S.lang, pl).key === 'mastered') mastered++; else if (!next) next = pl; });
  return { mastered, total: PLACES.length, langName: L(LANGS[S.lang].name), next: next ? L(next.name) : null };
}
function notify(){ try { document.dispatchEvent(new CustomEvent('plaza:change', { detail: stats() })); } catch(_){} }
window.PlazaApp = {
  stats,
  show(){ if (!SC) renderHome(); },
  home(){ if (SC) closeScene(); else renderHome(); },
  followSiteLanguage(siteLang){ const want = siteLang === 'es' ? 'en' : 'es'; if (S.lang !== want && !SC) { S.lang = want; save(); renderHome(); } },
};

/* boot */
loadLocal();
renderHome();
connectDb();
notify();
})();
