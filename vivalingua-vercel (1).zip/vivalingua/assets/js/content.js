// One global switch (site language) controls two things at once:
//  - which language the interface is displayed in
//  - which language the course actually teaches
// 'es' = Spanish interface, teaching English (for Spanish speakers)
// 'en' = English interface, teaching Spanish (for English speakers)

const SITE_TEXT = {
  es: {
    'nav.courses': 'Cursos', 'nav.how': 'Cómo funciona', 'nav.placement': 'Examen de nivel',
    'nav.login': 'Iniciar sesión', 'nav.cta': 'Comienza gratis', 'nav.logout': 'Salir',
    'hero.eyebrow': 'PIENSA · HABLA · VIVE',
    'hero.title': 'Habla un nuevo idioma. <span>Vive su cultura.</span>',
    'hero.text': 'Aprende inglés mediante conversaciones reales, historias, clases en vivo y experiencias para viajar, estudiar, trabajar y conectar con otras culturas.',
    'hero.cta1': 'Comienza gratis', 'hero.cta2': 'Descubre tu nivel',
    'hero.cardTitle': 'Conoce a la Familia Navas',
    'hero.cardText': 'José, Susana, Isabel y Max acompañan al estudiante durante su recorrido.',
    'how.eyebrow': 'CÓMO FUNCIONA', 'how.title': 'Tu camino hacia otro idioma.',
    'how.s1t': 'Descubre tu nivel', 'how.s1d': 'Evaluación inicial gratuita.',
    'how.s2t': 'Empieza gratis', 'how.s2d': 'Prueba las primeras clases.',
    'how.s3t': 'Aprende hablando', 'how.s3d': 'Videos, clases y conversaciones.',
    'how.s4t': 'Vive la cultura', 'how.s4d': 'Misiones de la vida real.',
    'courses.eyebrow': 'PROGRAMAS', 'courses.title': 'Encuentra tu nivel.',
    'courses.c1title': 'Básico', 'courses.c1desc': 'Fundamentos y situaciones cotidianas.',
    'courses.c2title': 'Intermedio', 'courses.c2desc': 'Conversaciones naturales, viajes, estudio y trabajo.',
    'courses.c3title': 'Avanzado', 'courses.c3desc': 'Comunicación académica, profesional y cultural.',
    'register.eyebrow': 'COMIENZA AQUÍ', 'register.title': 'Descubre dónde comienza tu viaje.',
    'register.text': 'Crea tu perfil y realiza una evaluación inicial.',
    'register.langNote': 'Estás aprendiendo <strong>inglés</strong>. ¿Prefieres aprender español?',
    'register.langSwitch': 'Cambiar a español',
    'register.nameLabel': 'Nombre', 'register.emailLabel': 'Email',
    'register.cta': 'Comenzar examen de nivel',
    'placement.eyebrow': 'EXAMEN DE NIVEL', 'placement.title': 'Evaluación rápida',
    'placement.text': 'Responde 5 preguntas. Este prototipo recomienda un nivel automáticamente.',
    'placement.cta': 'Ver resultado', 'placement.incomplete': 'Responde las 5 preguntas.',
    'placement.level1': 'Nivel 1 — Básico', 'placement.level2': 'Nivel 2 — Intermedio', 'placement.level3': 'Nivel 3 — Avanzado',
    'placement.resultPrefix': 'Tu nivel recomendado:', 'placement.continue': 'Continuar al login',
    langLabel: 'EN', langName: 'inglés',
  },
  en: {
    'nav.courses': 'Courses', 'nav.how': 'How it works', 'nav.placement': 'Placement test',
    'nav.login': 'Log in', 'nav.cta': 'Start for free', 'nav.logout': 'Log out',
    'hero.eyebrow': 'THINK · SPEAK · LIVE',
    'hero.title': 'Speak a new language. <span>Live its culture.</span>',
    'hero.text': 'Learn Spanish through real conversations, stories, live classes, and experiences built for travel, study, work, and connecting with other cultures.',
    'hero.cta1': 'Start for free', 'hero.cta2': 'Find your level',
    'hero.cardTitle': 'Meet the Navas Family',
    'hero.cardText': 'José, Susana, Isabel, and Max guide students through their journey.',
    'how.eyebrow': 'HOW IT WORKS', 'how.title': 'Your path to another language.',
    'how.s1t': 'Find your level', 'how.s1d': 'Free initial assessment.',
    'how.s2t': 'Start for free', 'how.s2d': 'Try the first classes.',
    'how.s3t': 'Learn by speaking', 'how.s3d': 'Videos, classes, and conversations.',
    'how.s4t': 'Live the culture', 'how.s4d': 'Real-life missions.',
    'courses.eyebrow': 'PROGRAMS', 'courses.title': 'Find your level.',
    'courses.c1title': 'Beginner', 'courses.c1desc': 'Fundamentals and everyday situations.',
    'courses.c2title': 'Intermediate', 'courses.c2desc': 'Natural conversation, travel, study, and work.',
    'courses.c3title': 'Advanced', 'courses.c3desc': 'Academic, professional, and cultural communication.',
    'register.eyebrow': 'START HERE', 'register.title': 'Find out where your journey begins.',
    'register.text': 'Create your profile and take an initial assessment.',
    'register.langNote': "You're learning <strong>Spanish</strong>. Prefer to learn English instead?",
    'register.langSwitch': 'Switch to English',
    'register.nameLabel': 'Name', 'register.emailLabel': 'Email',
    'register.cta': 'Start placement test',
    'placement.eyebrow': 'PLACEMENT TEST', 'placement.title': 'Quick assessment',
    'placement.text': 'Answer 5 questions. This prototype recommends a level automatically.',
    'placement.cta': 'See result', 'placement.incomplete': 'Please answer all 5 questions.',
    'placement.level1': 'Level 1 — Beginner', 'placement.level2': 'Level 2 — Intermediate', 'placement.level3': 'Level 3 — Advanced',
    'placement.resultPrefix': 'Your recommended level:', 'placement.continue': 'Continue to login',
    langLabel: 'ES', langName: 'Spanish',
  },
};

// Placement quiz: testing the *target* language, in each case written so the
// question stem is understandable in the interface language.
const QUIZ = {
  es: [
    ['Choose the correct greeting: “___! Nice to meet you.”', ['Goodbye', 'Hello', 'Tomorrow'], 1],
    ['Complete: “My name ___ José.”', ['are', 'is', 'be'], 1],
    ['At a restaurant you say:', ['I would like the chicken, please.', 'My airplane is blue.', 'Turn yesterday.'], 0],
    ['Which sentence is correct?', ['She go to work every day.', 'She goes to work every day.', 'She going work yesterday.'], 1],
    ['You are lost. What do you ask?', ['Could you help me find this address?', 'How many food is tomorrow?', 'Where weather are?'], 0],
  ],
  en: [
    ['Choose the correct greeting: “___! Mucho gusto.”', ['Adiós', 'Hola', 'Mañana'], 1],
    ['Complete: “Mi nombre ___ José.”', ['son', 'es', 'ser'], 1],
    ['At a restaurant you say:', ['Quisiera el pollo, por favor.', 'Mi avión es azul.', 'Gira ayer.'], 0],
    ['Which sentence is correct?', ['Ella va al trabajo todos los días.', 'Ella ir trabajo cada día.', 'Ella yendo trabajo ayer.'], 0],
    ['You are lost. What do you ask?', ['¿Podría ayudarme a encontrar esta dirección?', '¿Cuánta comida es mañana?', '¿Dónde clima son?'], 0],
  ],
};

// Level 1 unit titles — named in the target language either way, since
// that's how the course itself would label its own units.
// The 25 lessons are split into two levels. Lesson numbers stay 1–25 across both.
const LESSON_LEVELS = [
  { num: 1, es: 'Básico', en: 'Beginner', from: 0, to: 12 },
  { num: 2, es: 'Intermedio', en: 'Intermediate', from: 13, to: 24 },
];

const LEVEL1_LESSONS = {
  es: ['The Alphabet', 'Greetings & Introductions', 'About Me', 'Hobbies & Interests', 'Hobbies & Interests II', 'My Family', 'My Family II', 'Everyday Objects', 'Clothes & Colors', 'Daily Routines', 'Current Activities', 'Time & Calendar', 'Weather', 'Jobs & Professions', 'Jobs & Professions II', 'Food', 'Restaurants & Food', 'Money', 'Shopping', 'Home', 'Community', 'Health', 'Health & Emergencies', 'Directions & Travel', 'Final Review'],
  en: ['El alfabeto', 'Saludos y presentaciones', 'Sobre mí', 'Pasatiempos e intereses', 'Pasatiempos e intereses II', 'Mi familia', 'Mi familia II', 'Objetos cotidianos', 'Ropa y colores', 'Rutinas diarias', 'Actividades actuales', 'La hora y el calendario', 'El clima', 'Profesiones y trabajos', 'Profesiones y trabajos II', 'La comida', 'Restaurantes y comida', 'El dinero', 'De compras', 'La casa', 'La comunidad', 'La salud', 'Salud y emergencias', 'Direcciones y viajes', 'Repaso final'],
};

// Full detail for Lesson 2, the sample lesson shown in the student portal —
// mirrored so either track has a complete, coherent story and vocab set.
const LESSON2 = {
  es: {
    title: 'Greetings & Introductions',
    intro: 'La Familia Navas llega a Londres.',
    story: [
      ['Officer', 'Good afternoon. Welcome to London.'],
      ['José', 'Good afternoon.'],
      ['Officer', 'Could you spell your last name, please?'],
      ['José', 'N-A-V-A-S.'],
    ],
    vocab: [
      ['Hello', 'Hola'],
      ['Nice to meet you', 'Mucho gusto'],
      ['Could you spell that?', '¿Podría deletrearlo?'],
    ],
    missionPrompt: 'Graba una presentación de 30–60 segundos.',
    missionPlaceholder: 'Hello! My name is...',
    missionCta: 'Subir audio o video',
    completeCta: 'Completar lección',
  },
  en: {
    title: 'Saludos y presentaciones',
    intro: 'The Navas family arrives in Madrid.',
    story: [
      ['Agent', 'Buenas tardes. Bienvenidos a Madrid.'],
      ['José', 'Buenas tardes.'],
      ['Agent', '¿Podría deletrear su apellido, por favor?'],
      ['José', 'N-A-V-A-S.'],
    ],
    vocab: [
      ['Hola', 'Hello'],
      ['Mucho gusto', 'Nice to meet you'],
      ['¿Podría deletrearlo?', 'Could you spell that?'],
    ],
    missionPrompt: 'Record a 30–60 second introduction.',
    missionPlaceholder: '¡Hola! Me llamo...',
    missionCta: 'Upload audio or video',
    completeCta: 'Complete lesson',
  },
};

// --- Shared UI strings used on the dashboard-style pages (student/teacher/admin/login) ---
const APP_TEXT = {
  es: {
    'app.logout': 'Salir', 'app.backHome': '← Inicio',
    'login.eyebrow': 'BIENVENIDO', 'login.title1': 'Tu aprendizaje.', 'login.title2': 'Tu espacio.',
    'login.text': 'Una sola puerta de entrada. El sistema identifica automáticamente si eres alumno, profesor o administrador.',
    'login.formEyebrow': 'INICIAR SESIÓN', 'login.formTitle': 'Bienvenido de nuevo', 'login.formText': 'Ingresa tus credenciales.',
    'login.emailLabel': 'Correo', 'login.passwordLabel': 'Contraseña', 'login.remember': 'Recordarme',
    'login.submit': 'Entrar', 'login.demoAccounts': 'CUENTAS DE PRUEBA',
    'login.demoStudent': '🎓 Alumno', 'login.demoTeacher': '👩‍🏫 Profesor', 'login.demoAdmin': '⚙️ Admin',
    'student.portalEyebrow': 'PORTAL DEL ESTUDIANTE', 'student.continueText': 'Continúa avanzando en tu recorrido.',
    'student.navHome': '🏠 Inicio', 'student.navCourse': '📚 Mi curso', 'student.navLesson': '🎯 Lección actual',
    'student.statProgress': 'Progreso', 'student.statLessons': 'Lecciones', 'student.statBadges': 'Insignias', 'student.statTime': 'Tiempo aprendido',
    'student.continueCard': 'CONTINÚA', 'student.continueLesson': 'Continuar lección',
    'student.nextClass': 'PRÓXIMA CLASE', 'student.nextClassName': 'Conversation Practice', 'student.nextClassTime': 'Miércoles · 7:00 PM',
    'student.courseEyebrow': 'NIVELES 1 Y 2', 'student.courseTitle': 'Tu curso de inglés', 'student.courseCount': '25 lecciones: 13 de nivel básico y 12 de nivel intermedio',
    'student.lessonEyebrow': 'LECCIÓN 2', 'student.storyTitle': 'Historia', 'student.vocabTitle': 'Vocabulario',
    'student.missionTitle': 'Misión', 'student.missionLabel': 'Tu práctica', 'student.progressTitle': 'PROGRESO',
  },
  en: {
    'app.logout': 'Log out', 'app.backHome': '← Home',
    'login.eyebrow': 'WELCOME', 'login.title1': 'Your learning.', 'login.title2': 'Your space.',
    'login.text': 'One single entry point. The system automatically detects whether you are a student, teacher, or administrator.',
    'login.formEyebrow': 'LOG IN', 'login.formTitle': 'Welcome back', 'login.formText': 'Enter your credentials.',
    'login.emailLabel': 'Email', 'login.passwordLabel': 'Password', 'login.remember': 'Remember me',
    'login.submit': 'Log in', 'login.demoAccounts': 'DEMO ACCOUNTS',
    'login.demoStudent': '🎓 Student', 'login.demoTeacher': '👩‍🏫 Teacher', 'login.demoAdmin': '⚙️ Admin',
    'student.portalEyebrow': 'STUDENT PORTAL', 'student.continueText': 'Keep moving forward on your journey.',
    'student.navHome': '🏠 Home', 'student.navCourse': '📚 My course', 'student.navLesson': '🎯 Current lesson',
    'student.statProgress': 'Progress', 'student.statLessons': 'Lessons', 'student.statBadges': 'Badges', 'student.statTime': 'Time learned',
    'student.continueCard': 'CONTINUE', 'student.continueLesson': 'Continue lesson',
    'student.nextClass': 'NEXT CLASS', 'student.nextClassName': 'Conversation Practice', 'student.nextClassTime': 'Wednesday · 7:00 PM',
    'student.courseEyebrow': 'LEVELS 1 AND 2', 'student.courseTitle': 'Your Spanish course', 'student.courseCount': '25 lessons: 13 beginner and 12 intermediate',
    'student.lessonEyebrow': 'LESSON 2', 'student.storyTitle': 'Story', 'student.vocabTitle': 'Vocabulary',
    'student.missionTitle': 'Mission', 'student.missionLabel': 'Your practice', 'student.progressTitle': 'PROGRESS',
  },
};

// Watercolor story scenarios woven through every Level 1 topic.
const LEVEL1_SCENARIOS = {
  es: [
    ['The Alphabet','Max sees an alphabet mural at school and practices spelling names with Susana.','Max','Can you spell your name?','Susana','S-U-S-A-N-A.'],
    ['Greetings & Introductions','La Familia Navas llega a Londres y conoce al agente de inmigración.','Officer','Good afternoon. What is your name?','José','My name is José Navas. Nice to meet you.'],
    ['About Me','Isabel meets a new classmate and shares a few facts about herself.','Isabel','I am Isabel. I am a student and I love art.','Friend','Nice to meet you, Isabel!'],
    ['Hobbies & Interests','Max and José plan their Saturday activities in the park.','Max','I like soccer and drawing. What do you like?','José','I like music and walking.'],
    ['Hobbies & Interests II','Susana and Isabel compare indoor and outdoor hobbies on a rainy day.','Susana','Do you like reading?','Isabel','Yes, and I love taking photos.'],
    ['My Family','Max introduces the Navas family in a class presentation.','Max','This is my family. José is my dad and Susana is my mom.','Teacher','What a lovely family!'],
    ['My Family II','The family makes a photo album and describes relatives.','Isabel','My brother is funny and energetic.','Susana','And your grandparents are very kind.'],
    ['Everyday Objects','José cannot find his travel essentials before leaving the hotel.','José','Where are my keys and phone?','Max','Your phone is on the table.'],
    ['Clothes & Colors','Isabel and Susana choose outfits for a family celebration.','Isabel','I like the blue dress.','Susana','The blue one looks beautiful.'],
    ['Daily Routines','Max explains his school-day routine over breakfast.','Max','I wake up at seven and go to school at eight.','José','And we eat breakfast together.'],
    ['Current Activities','The family video-calls a friend while everyone is busy.','Friend','What are you doing?','Susana','I am cooking, and Max is studying.'],
    ['Time & Calendar','José organizes the family schedule for the week.','José','What time is the museum tour?','Isabel','It is Tuesday at ten thirty.'],
    ['Weather','The family checks the forecast before a day trip.','Susana','What is the weather like today?','Max','It is sunny, but a little windy.'],
    ['Jobs & Professions','Max interviews family members for a school project about careers.','Max','What do you do for work?','José','I work with people and solve problems.'],
    ['Jobs & Professions II','Isabel visits a community career fair and asks about different jobs.','Isabel','What does a nurse do?','Guide','A nurse helps care for people.'],
    ['Food','The family prepares breakfast and names ingredients in the kitchen.','Susana','We need eggs, fruit, bread, and milk.','Max','I can wash the fruit!'],
    ['Restaurants & Food','The Navas family orders dinner at a neighborhood restaurant.','Server','Are you ready to order?','José','Yes. I would like the chicken, please.'],
    ['Money','Max learns to count bills and coins while buying a postcard.','Clerk','That is five pounds.','Max','Here is ten. How much change?'],
    ['Shopping','Isabel shops for a gift and asks about size, color, and price.','Isabel','Do you have this in a smaller size?','Clerk','Yes, and it also comes in green.'],
    ['Home','Susana gives a friend a video tour of the family apartment.','Susana','This is the kitchen, and the bedrooms are upstairs.','Friend','Your living room is bright!'],
    ['Community','The family explores the neighborhood and identifies useful places.','Max','Where is the library?','José','It is next to the pharmacy.'],
    ['Health','Max feels tired, so Susana helps him describe simple symptoms.','Susana','How do you feel?','Max','I have a headache and I am tired.'],
    ['Health & Emergencies','José practices asking for help during an emergency scenario.','José','We need help. Please call an ambulance.','Operator','What is your location?'],
    ['Directions & Travel','The family asks for directions while finding a train station.','Isabel','Excuse me, how do we get to the station?','Local','Go straight and turn left at the bank.'],
    ['Final Review','The family celebrates the trip by using everything they learned during one final day out.','José','We can introduce ourselves, order food, shop, and ask directions!','Max','And I can do it in English!']
  ],
  en: [
    ['El alfabeto','Max ve un mural del alfabeto en la escuela y practica deletrear nombres con Susana.','Max','¿Cómo se deletrea tu nombre?','Susana','S-U-S-A-N-A.'],
    ['Saludos y presentaciones','La familia Navas llega a Madrid y conoce al agente de inmigración.','Agente','Buenas tardes. ¿Cómo se llama?','José','Me llamo José Navas. Mucho gusto.'],
    ['Sobre mí','Isabel conoce a una nueva compañera y comparte algunos datos sobre sí misma.','Isabel','Soy Isabel. Soy estudiante y me encanta el arte.','Amiga','¡Mucho gusto, Isabel!'],
    ['Pasatiempos e intereses','Max y José planean sus actividades del sábado en el parque.','Max','Me gusta el fútbol y dibujar. ¿Qué te gusta?','José','Me gusta la música y caminar.'],
    ['Pasatiempos e intereses II','Susana e Isabel comparan pasatiempos para un día de lluvia.','Susana','¿Te gusta leer?','Isabel','Sí, y me encanta tomar fotos.'],
    ['Mi familia','Max presenta a la familia Navas en su clase.','Max','Esta es mi familia. José es mi papá y Susana es mi mamá.','Maestra','¡Qué linda familia!'],
    ['Mi familia II','La familia prepara un álbum y describe a sus parientes.','Isabel','Mi hermano es divertido y enérgico.','Susana','Y tus abuelos son muy amables.'],
    ['Objetos cotidianos','José busca sus cosas antes de salir del hotel.','José','¿Dónde están mis llaves y mi teléfono?','Max','Tu teléfono está sobre la mesa.'],
    ['Ropa y colores','Isabel y Susana eligen ropa para una celebración familiar.','Isabel','Me gusta el vestido azul.','Susana','El azul te queda muy bonito.'],
    ['Rutinas diarias','Max explica su rutina escolar durante el desayuno.','Max','Me levanto a las siete y voy a la escuela a las ocho.','José','Y desayunamos juntos.'],
    ['Actividades actuales','La familia hace una videollamada mientras todos están ocupados.','Amiga','¿Qué están haciendo?','Susana','Estoy cocinando y Max está estudiando.'],
    ['La hora y el calendario','José organiza el calendario familiar de la semana.','José','¿A qué hora es la visita al museo?','Isabel','Es el martes a las diez y media.'],
    ['El clima','La familia mira el pronóstico antes de una excursión.','Susana','¿Qué tiempo hace hoy?','Max','Hace sol, pero hace un poco de viento.'],
    ['Profesiones y trabajos','Max entrevista a su familia para un proyecto escolar sobre profesiones.','Max','¿En qué trabajas?','José','Trabajo con personas y resuelvo problemas.'],
    ['Profesiones y trabajos II','Isabel visita una feria de profesiones de la comunidad.','Isabel','¿Qué hace una enfermera?','Guía','Una enfermera ayuda a cuidar a las personas.'],
    ['La comida','La familia prepara el desayuno y nombra los ingredientes.','Susana','Necesitamos huevos, fruta, pan y leche.','Max','¡Yo puedo lavar la fruta!'],
    ['Restaurantes y comida','La familia Navas cena en un restaurante del barrio.','Mesero','¿Están listos para ordenar?','José','Sí. Quisiera el pollo, por favor.'],
    ['El dinero','Max aprende a contar dinero mientras compra una postal.','Cajera','Son cinco euros.','Max','Aquí tiene diez. ¿Cuánto es el cambio?'],
    ['De compras','Isabel compra un regalo y pregunta por talla, color y precio.','Isabel','¿Tiene esto en una talla más pequeña?','Cajera','Sí, y también viene en verde.'],
    ['La casa','Susana hace una videollamada para mostrar la casa.','Susana','Esta es la cocina y los dormitorios están arriba.','Amiga','¡La sala tiene mucha luz!'],
    ['La comunidad','La familia explora el barrio e identifica lugares útiles.','Max','¿Dónde está la biblioteca?','José','Está al lado de la farmacia.'],
    ['La salud','Max está cansado y Susana le ayuda a describir síntomas sencillos.','Susana','¿Cómo te sientes?','Max','Me duele la cabeza y estoy cansado.'],
    ['Salud y emergencias','José practica cómo pedir ayuda en una emergencia.','José','Necesitamos ayuda. Llame a una ambulancia, por favor.','Operador','¿Cuál es su ubicación?'],
    ['Direcciones y viajes','La familia pide indicaciones para encontrar la estación.','Isabel','Disculpe, ¿cómo llegamos a la estación?','Local','Sigan derecho y giren a la izquierda en el banco.'],
    ['Repaso final','La familia celebra usando todo lo aprendido durante un último día de viaje.','José','¡Podemos presentarnos, pedir comida, comprar y pedir indicaciones!','Max','¡Y puedo hacerlo en español!']
  ]
};
