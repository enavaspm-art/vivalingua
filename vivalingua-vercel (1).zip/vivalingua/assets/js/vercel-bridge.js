// VivaLingua on Vercel: connects the site to its own server.
// It provides the same window.claude.use('db' | 'user' | 'sample') interface the
// app was written for, backed by /api/data, /api/login and /api/plaza.
(function () {
  const TOKEN_KEY = 'vlToken';
  const store = {
    get() { try { return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY); } catch (e) { return null; } },
    set(t, remember) {
      try {
        localStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(TOKEN_KEY);
        if (t) (remember ? localStorage : sessionStorage).setItem(TOKEN_KEY, t);
      } catch (e) {}
    },
  };
  const fail = (code, message) => { const e = new Error(message || code); e.code = code; return e; };

  async function api(path, opts = {}) {
    const headers = { 'Content-Type': 'application/json' };
    const t = store.get();
    if (t) headers.Authorization = 'Bearer ' + t;
    let r;
    try {
      r = await fetch(path, { method: opts.body ? 'POST' : 'GET', headers, body: opts.body ? JSON.stringify(opts.body) : undefined, signal: opts.signal });
    } catch (e) {
      if (e && e.name === 'AbortError') throw fail('cancelled');
      throw fail('network');
    }
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw fail(r.status === 429 ? 'rate_limited' : data.code || 'http_' + r.status, data.error);
    return data;
  }

  // ---- database (polls for changes instead of live updates)
  const refreshers = {};
  async function write(op, col, id, data) {
    const out = await api('/api/data', { body: { op, col, id, data } });
    if (out.token) store.set(out.token, true);
    if (out.password && typeof window.VL_onStudentPassword === 'function') window.VL_onStudentPassword(out.password);
    (refreshers[col] || []).forEach(fn => fn());
    return out;
  }
  const q = (col, id) => '/api/data?col=' + encodeURIComponent(col) + (id != null ? '&id=' + encodeURIComponent(id) : '');
  const db = {
    collection(col) {
      return {
        onSnapshot(cb) {
          let stopped = false, timer = null;
          const tick = async () => {
            clearTimeout(timer);
            if (stopped) return;
            try {
              const d = await api(q(col));
              if (!stopped) cb({ docs: (d.docs || []).map(x => ({ id: x.id, data: () => x.data })) });
            } catch (e) { /* keep polling */ }
            if (!stopped) timer = setTimeout(tick, document.hidden ? 60000 : 15000);
          };
          (refreshers[col] = refreshers[col] || []).push(tick);
          tick();
          return () => { stopped = true; clearTimeout(timer); };
        },
        doc(id) {
          return {
            set: data => write('set', col, id, data),
            update: data => write('update', col, id, data),
            delete: () => write('delete', col, id),
            get: async () => { const d = await api(q(col, id)); return { exists: !!d.doc, data: () => d.doc }; },
          };
        },
      };
    },
  };

  // ---- La Plaza AI
  const sample = { json: (prompt, opts = {}) => api('/api/plaza', { body: { prompt }, signal: opts.signal }) };

  window.claude = {
    use(name) {
      if (name === 'db') return Promise.resolve(db);
      if (name === 'sample') return Promise.resolve(sample);
      return Promise.resolve(null); // 'user': La Plaza progress stays in this browser
    },
  };

  window.VL = {
    hasToken: () => !!store.get(),
    async login(email, password, remember) {
      const out = await api('/api/login', { body: { email, password } });
      store.set(out.token, remember);
      Object.values(refreshers).flat().forEach(fn => fn());
      return out;
    },
    logout() { store.set(null); },
  };
})();
